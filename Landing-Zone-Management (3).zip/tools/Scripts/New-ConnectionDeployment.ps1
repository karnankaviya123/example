
<#
    .SYNOPSIS
    Creates VNet connection.

    .DESCRIPTION
    Creates VNet connection between workload VNet and Virtual Hub.

    .PARAMETER virtualNetworkResourceId
    Mandatory. Id of virtual network to be peered with Virtual HUB

    .EXAMPLE
    ./tools/Scripts/New-ConnectionDeployment.ps1  -WhatIf:$true
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $virtualNetworkResourceId
)

# Get Virtual network ID for deployment
$virtualNetworksGraphQuery = "resources 
| where type == 'microsoft.network/virtualnetworks' 
| where id == '{0}'"-f $virtualNetworkResourceId

$remoteVirtualNetwork = Search-AzGraph -Query $virtualNetworksGraphQuery

if (-not $remoteVirtualNetwork){
    Write-Verbose ("Virtual Network not found. VNet Resource Id" -f $virtualNetworkResourceId) -Verbose
    throw "Virtual Network not found"
}

# Get subscription name and construct VNet connection name
$subscriptionId = $virtualNetworkResourceId.Split('/')[2]

$subscriptionGraphQuery = "resourcecontainers
| where type == 'microsoft.resources/subscriptions'
| where subscriptionId == '{0}'" -f $subscriptionId

$subscriptionDetails = Search-AzGraph -Query $subscriptionGraphQuery
$connectionName = "er-vhub-to-"+$subscriptionDetails.Name -replace "sub-"

# Deployment template for VNet Connection

$templateParameterObject = @{
    virtualNetworkResourceId = $virtualNetworkResourceId
    connectionName           = $connectionName
}

$deploymentParams = @{
    DeploymentName          = "LZ-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
    TemplateFile            = "$PSScriptRoot/../.bicep/deployVNetConnection.bicep"
    location                = "westeurope"
    TemplateParameterObject = $templateParameterObject 
    Verbose                 = $true
}

Write-Verbose "Invoke deployment with" -Verbose
Write-Verbose ($deploymentParams | ConvertTo-Json | Out-String) -Verbose

Test-AzSubscriptionDeployment @deploymentParams 

if ($PSCmdlet.ShouldProcess("Subscription-level deployment for subscription [$subscriptionName]", "Invoke")) {
    $res = New-AzSubscriptionDeployment @deploymentParams
    Write-Verbose ($res.Outputs | ConvertTo-Json -Depth 10 | Out-String) -Verbose
}
else {
    New-AzSubscriptionDeployment @deploymentParams -WhatIf
}