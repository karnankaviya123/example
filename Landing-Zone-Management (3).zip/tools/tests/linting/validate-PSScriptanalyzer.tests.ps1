Write-Host  "##[group]Start PSScriptanalyze Pester Tests"

#Configuration
$PSScriptAnalyzerSettings = @{
    Severity     = @('Error', 'Warning') #, 'Information')
    ExcludeRules = @('PSAvoidUsingWMICmdlet', 'PSAvoidUsingWriteHost')
    #ExcludeRules = @()
}
$GeneralConfig = @{
    ExcludeFiles         = @('*.tests.ps1')
    CommonHelpParameters = @('Debug', 'ErrorAction', 'ErrorVariable', 'InformationAction', 'InformationVariable', 'OutBuffer', 'OutVariable', 'PipelineVariable', 'Verbose', 'WarningAction', 'WarningVariable', 'WhatIf', 'Confirm')
}

#Get ps1 Files recursively
$PS1Files = Get-ChildItem -Recurse -Include '*.ps1' -Exclude $GeneralConfig.ExcludeFiles 

#Only Run if there are any ps1 files
if ($PS1Files.count -gt 0) {
    #Install PSScriptanalyzer if needed
    if ($null -eq $(Get-Module -Name PSScriptAnalyzer)) {
        Write-Host  "Install-Module -Name PSScriptAnalyzer -Force"
        Install-Module -Name PSScriptAnalyzer -Force
        Import-Module -Name PSScriptAnalyzer
    }

    Write-host "Start Tests"
    Describe 'General - Testing all scripts and modules against the Script Analyzer Rules' {
        Context "Checking files to test exist and Invoke-ScriptAnalyzer cmdLet is available" {
            It "Checking Invoke-ScriptAnalyzer exists." {
                { Get-Command Invoke-ScriptAnalyzer -ErrorAction Stop } | Should -Not -Throw
            }
        }
    }

    foreach ($PS1File in $PS1Files) { 
        
        Describe "$(($PS1File.fullname).Replace("$(Get-Location)",''))" {
            Context "Help" { 
                $Help = Get-Help $($PS1File.FullName)
                $TestCases = @{Help = $Help }
                # A Synopsis, Description and Examples should be provided with each Script
                It 'not Empty' -TestCases $TestCases {
                    $Help | should -not -benullorempty
                }
                $TestCases = @{Help = $Help }
                It 'Synopsis' -TestCases $TestCases {
                    $Help | Select-Object -ExpandProperty synopsis | should -not -benullorempty
                }
                It 'Description' -TestCases $TestCases {
                    $Help | Select-Object -ExpandProperty Description | should -not -benullorempty
                }
                It 'Examples' -TestCases $TestCases {
                    $Examples = $Help | Select-Object -ExpandProperty Examples | Measure-Object 
                    $Examples.Count -gt 0 | Should -BeTrue
                }
                #a Help and Description should be present for each Parameter
                $parameters = $(Get-Command $PS1File.FullName).ParameterSets.Parameters | Sort-Object -Property Name -Unique | Where-Object Name -notin $GeneralConfig.CommonHelpParameters
                foreach ($parameter in $parameters) {
                    $HelpForThisParameter = $Help.parameters.parameter | Where-Object { $_.Name -EQ $parameter.Name }
                    $TestCases = @{HelpForThisParameter = $HelpForThisParameter }
                    It "Param $($parameter.name) exists" -TestCases $TestCases {
                        $HelpForThisParameter | should -Not -BeNullOrEmpty
                    }
                    It "Param $($parameter.name) description exists" -TestCases $TestCases {
                        $HelpForThisParameter.description | should -Not -BeNullOrEmpty
                    }
                }
            }
            Context "PSScriptanalyzer" {
                # All PSScriptAnalyzer Rules need to be satisfied
                forEach ($scriptAnalyzerRule in Get-ScriptAnalyzerRule) {
                    It "$($scriptAnalyzerRule)" -TestCases @{File = $PS1File; PSScriptAnalyzerSettings = $PSScriptAnalyzerSettings ; scriptAnalyzerRule = $scriptAnalyzerRule } {
                        param($file, $PSScriptAnalyzerSettings, $scriptAnalyzerRule)
                        $ScriptAnalyzes = Invoke-ScriptAnalyzer -Settings $PSScriptAnalyzerSettings -Path $($File.FullName) -IncludeRule $scriptAnalyzerRule
                        "$($ScriptAnalyzes.Line)$($ScriptAnalyzes.Message)" | Should -BeNullOrEmpty 
                    }
                }

            }
        }
    }

}
else {
    Describe "PSSCriptanalyzertests" {
        Context "Test" {
            It 'No ps1 Files to Test' {
                $true | Should -BeTrue
            }
        }
    }
}

Write-Host  "##[endgroup]"
