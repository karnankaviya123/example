# Wiki content

Core
- [Home](./Home)
- [Creating images with the Azure Image Builder](./Creating%20images%20with%20the%20Azure%20Image%20Builder)
- [Self-hosted Azure DevOps Virtual Machine Scale Set Agents](./Self-hosted%20Azure%20DevOps%20Virtual%20Machine%20Scale%20Set%20Agents)

Shared concepts
- [Staging](./Staging)