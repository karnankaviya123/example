
function Get-VirtualNetworkConnection {
    <#
    .SYNOPSIS
    Get virtual network peering

    .DESCRIPTION
    Get virtual network peering and virtual network connection from Virtual Hub

    .PARAMETER subscriptionName
    Required. Name of Subscription.

    .PARAMETER virtualHubName
    Required. Name of Virtual Hub.

    .PARAMETER virtualHubSubscription
    Required. Name of subscription where Virtual Hub is deployed.

    .EXAMPLE
    Get-VirtualNetworkPeerings -subscriptionName "sub-xxx-xxx" -virtualHubName "vhub-001" -virtualHubSubscription "sub-yyy-xxx"

    #>

    [CmdletBinding()]
    param (
        [parameter(mandatory = $true)]
        [string] $subscriptionName,
        [parameter(mandatory = $true)]
        [string] $virtualHubName,
        [parameter(mandatory = $true)]
        [string] $virtualHubSubscription,
        [parameter(mandatory = $false)]
        [string] $virtualNetworkResourceId
    )
    
    $subscriptionGraphQuery = "resourcecontainers
        | where type == 'microsoft.resources/subscriptions'
        | where name == '{0}'" -f $subscriptionName
    $subscriptionProperties = Search-AzGraph -Query $subscriptionGraphQuery
    $virtualHubGraphQuery = "resources 
        | where type == 'microsoft.network/virtualhubs'
        | where name == '{0}'" -f $virtualHubName

    # Filter Virtual Networks by Resource ID (if provided)
    if (-not [String]::IsNullOrEmpty($virtualNetworkResourceId)) {
        $virtualNetworksGraphQuery = "resources 
        | where type == 'microsoft.network/virtualnetworks'
        | where id == '{0}'" -f $virtualNetworkResourceId
    }
    else {
        $virtualNetworksGraphQuery = "resources 
        | where type == 'microsoft.network/virtualnetworks' 
        | where subscriptionId == '{0}'" -f $subscriptionProperties.subscriptionId
    }

    $virtualNetworks = Search-AzGraph -Query $virtualNetworksGraphQuery
    $virtualHubProperties = Search-AzGraph -Query $virtualHubGraphQuery

    $currentContext = Set-AzContext -Subscription $virtualHubSubscription
    If ($currentContext.subscription.Name -ne $virtualHubSubscription) { throw "Virtual Hub subscription not set as current context" }

    $virtualHubConnection = Get-AzVirtualHubVnetConnection -ResourceGroupName $virtualHubProperties.resourceGroup -VirtualHubName $virtualHubProperties.name | 
    Select-Object @{N='VirtualHubConnectionId'; E={$_.Id}}, Name -ExpandProperty RemoteVirtualNetwork | 
    Where-Object -Property Id -eq $virtualNetworks.id -Verbose

    return $virtualHubConnection
}
