<#
    .SYNOPSIS
    Checks if there are created more resource groups than default

    .DESCRIPTION
    Checks if there are created more resource groups than default

    .PARAMETER 


    .EXAMPLE
    ./tools/Scripts/Get-ResourceGroups.ps1 -managementGroupId "mgID"
#>

function Get-ResourceGroups {
  [CmdletBinding()]
  param (
    [parameter(Mandatory = $true)]
    [string] $managementGroupId
  )
  $ResourceGraphQuery = "resourcecontainers
| where type == 'microsoft.resources/subscriptions'
| where properties.managementGroupAncestorsChain[1].name=~'{0}'
| project name, subscriptionId, tags['ccoe_owner'], properties.managementGroupAncestorsChain[1].name" -f $managementGroupId
  $subInfo = Search-AzGraph -Query $ResourceGraphQuery
  Write-Verbose ("Subscritpion only with default resource groups. ") -Verbose
  $allSubscriptions = [System.Collections.ArrayList]@()
  foreach ($sub in $subInfo) {
    $ResourceGraphQueryRG = "resourcecontainers
    | where type == 'microsoft.resources/subscriptions/resourcegroups'
    | where resourceGroup notcontains 'rg-an-governance'
    | where resourceGroup notcontains '-ccoemgmt'
    | where resourceGroup notcontains 'networkwatcherrg'
    | where resourceGroup notcontains '-rsv-neu'
    | where resourceGroup notcontains '-rsv-weu'
    | where resourceGroup notcontains '-tfstate'
    | where resourceGroup notcontains '-vnet'
    | where subscriptionId =~ '{0}'" -f $sub.subscriptionId
    $RGInfo = Search-AzGraph -Query $ResourceGraphQueryRG
    if (($sub.name -ne "sub-lztstonline-dev") -and ($sub.name -ne "sub-lztstcorp-dev")) {
      if (!$RGInfo.resourceGroup) {
        Write-Verbose ("Potentially inactive sub: [{0}], [{1}]" -f $sub.name, $sub.subscriptionId ) -Verbose

        do {
          try {
            Set-AzContext -SubscriptionId $sub.subscriptionId -ErrorAction Stop -Verbose
            $setContextError = $false
          }
          catch {
            Write-Verbose ("{0} - Cannot set context to {1}. Retrying in 5 seconds." -f (Get-date -Format HH:mm:ss), $sub.subscriptionId) -Verbose
            $setContextError = $true
            $setContextAttempt++
            # stop pipeline when limit of Set-AzContext attempts is reached
            If ($setContextAttempt -gt $setContextLimit) {
              throw "Cannot set destination subscription. Please try running pipeline again"
            }
            Start-Sleep -Seconds 5
          }
        } while ($setContextError)
  
        $deployments = Get-AzSubscriptionDeployment | Sort-Object -Property Timestamp -Descending
        $otherDeployments = [System.Collections.ArrayList]@()
        
        
        # Write-Verbose ("Today is:  [{0}] " -f $dateAndTime) -Verbose
        foreach ($deployment in $deployments) {
          if (($deployment.deploymentName -notmatch "LZ-*") -and ($deployment.deploymentName -notmatch "PolicyDeployment-*")) {

            if ($deployment.Timestamp -gt (get-date).AddDays(-30)) {
              Write-Verbose ("Deployments no older then 30 days in Subscription:  [{0}] deployments:  [{1}], [{2}] " -f $sub.name, $deployment.timestamp, $deployment.id) -Verbose
              $null = $otherDeployments.Add($deployment) 

            }
          }
          if ($deployment.deploymentName -match "LZ-*") {
            if ($deployment.Timestamp -gt (get-date).AddDays(-30)) {
              $null = $otherDeployments.Add($deployment) 
            }
          }

        }
        if (!$otherDeployments) {
          $null = $allSubscriptions.Add($sub)
        }


        Write-Verbose ("The newest deployment Subscription:  [{0}] deployments:  [{1}], [{2}] " -f $sub.name, $deployments[0].timestamp, $deployments[0].id) -Verbose
        Write-Verbose ("The oldest deployment Subscription:  [{0}] deployments:  [{1}], [{2}] " -f $sub.name, $deployments[-1].timestamp, $deployments[-1].id) -Verbose
      }
    }

  }
  
  Write-Verbose ("All potentially inactive subscriptions:") -Verbose
  foreach ($subscription in $allSubscriptions) {
    Write-Verbose ("[{0}], [{1}] " -f $subscription.name, $subscription.subscriptionId) -Verbose
  }
}