<#
.SYNOPSIS
Creates Service Connections report

.DESCRIPTION
Creates Service Connections  report file in specified location

.PARAMETER Path
Required. Path where report files will be stored

.PARAMETER Name
Required. Report file name with extension

.EXAMPLE
New-ServiceConnectionsReport -Path ".\reports\" -Name "scReport.xlsx"

Returns report files
#>

function New-ServiceConnectionsReport {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $path,

        [Parameter(Mandatory = $true)]
        [string] $name
    )

    if (!(Test-Path -path $path)) {
        Write-Verbose ("Path [{0}] not found" -f $path) -Verbose
        throw "Incorrect Path. Directory must be created before use of New-ServiceConnectionsReport"
    }

    $reportPathAndName = ($path+'\'+$name+'.xlsx')
    $currentDate = Get-Date

    # Get list of Service Connections
    $uriServiceConnections = "https://dev.azure.com/an-de-ohg-sbi/AN-Azure-ControlRepo/_apis/serviceendpoint/endpoints?type=azurerm"
    $allServiceConnections = (Invoke-RESTDevOpsCommand -Method GET -uri $uriServiceConnections).Value

    # Get list of all AAD App Registrations
    $allAppRegistrations = az ad app list --all | ConvertFrom-Json

    foreach ($sc in $allServiceConnections) {
        if (($sc.type -eq "AzureRM") -and ($sc.authorization.scheme -eq "ServicePrincipal") -and ($sc.authorization.parameters.authenticationType -eq "spnKey")) {
            $app = $allAppRegistrations | Where {$_.appId -eq $sc.authorization.parameters.serviceprincipalid}
            $appSecrets = $app.passwordCredentials

            foreach ($secret in $appSecrets) {
                $expiresInDays = (New-TimeSpan -start $currentDate -end $secret.endDateTime).Days
                Write-Verbose ("Processing [{0}] [{1}] [{2}]" -f $sc.name, $app.displayName, $secret.displayName) -Verbose

                $output = [PSCustomObject][Ordered]@{
                    ServiceConnection   = $sc.name
                    SecretName          = $secret.displayName 
                    ExpiresInDays       = $expiresInDays
                    ExpirationDate      = $secret.endDateTime
                    SecretId            = $secret.keyId
                    SecretHint          = $secret.hint
                    AppDisplayName      = $app.displayName
                    AppId               = $app.appId
                }
                Write-Output $output
                $output | Export-Excel -Path $reportPathAndName -Append -WorksheetName "ServiceConnections"

            }
        }
    }

}