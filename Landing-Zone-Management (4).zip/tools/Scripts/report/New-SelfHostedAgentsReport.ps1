<#
.SYNOPSIS
Creates Self Hosted Agents report

.DESCRIPTION
Creates Self Hosted Agents report file in specified location

.PARAMETER Path
Required. Path where report files will be stored

.PARAMETER Name
Required. Report file name with extension

.EXAMPLE
New-SelfHostedAgentsReport  -Path ".\reports\" -Name "lzReport.xlsx"

Returns report files
#>

function New-SelfHostedAgentsReport {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $path,

        [Parameter(Mandatory = $true)]
        [string] $name
    )

    if (!(Test-Path -path $path)) {
        Write-Verbose ("Path [{0}] not found" -f $path) -Verbose
        throw "Incorrect Path. Directory must be created before use of New-SelfHostedAgentsReport"
    }

    $reportPathAndName = ($path+'\'+$name+'.xlsx')

    # Query subscription data with Resource Graph
    $agentsImageId = "/subscriptions/2a908d0e-8d21-458e-9d21-cb676e9568e5/resourceGroups/rg-ccoe-prd-weu-vmss-01/providers/Microsoft.Compute/galleries/aibgallery002/images/linux-sid-prod-001"
    $allScaleSetsQuery = "resources
    | where type == 'microsoft.compute/virtualmachinescalesets'
    | project name, subscriptionId, properties.virtualMachineProfile.storageProfile.imageReference.id, tags.ccoe_project
    | where properties_virtualMachineProfile_storageProfile_imageReference_id == '{0}'" -f $agentsImageId
    
    # Get all scale sets available for service connection
    $allScaleSets = Search-AzGraph -Query $allScaleSetsQuery -First 1000 -Verbose

    # Count number of teams by project name
    $agentUsers = ($allScaleSets.tags_ccoe_project | Group-Object | Measure-Object).Count

    # Get total number of agent pools
    $numberOfAgentPools = ($allScaleSets | Measure-Object).Count

    $allScaleSets = $allScaleSets | 
        Select-Object @{n="Scale set name";e={$_.name}},
            @{n="Project";e={$_.tags_ccoe_project}},
            @{n="SubscriptionId";e={$_.subscriptionId}}, 
            @{n="OS Image";e={$_.properties_virtualMachineProfile_storageProfile_imageReference_id}}

    $allScaleSets | Export-Excel -Path $reportPathAndName  -Append -WorksheetName "SelfHostedAgentPools"

    $output = @{} 
    $output.Add("agentUsers",$agentUsers)
    $output.Add("numberOfAgentPools",$numberOfAgentPools)

    return $output

}