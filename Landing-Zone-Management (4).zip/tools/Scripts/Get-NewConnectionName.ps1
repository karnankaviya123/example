<#
    .SYNOPSIS
    Creates VNet connection name.

    .DESCRIPTION
    Creates VNet connection name for connection deployment

    .PARAMETER virtualNetworkResourceId
    Mandatory. Id of virtual network to be peered with Virtual HUB

    .EXAMPLE
    ./tools/Scripts/New-ConnectionDeployment.ps1  -WhatIf:$true
#>
function Get-NewConnectionName {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory = $true)]
        [string] $virtualNetworkResourceId
    )

    # Get subscription details
    $subscriptionId = $virtualNetworkResourceId.Split('/')[2]

    $subscriptionGraphQuery = "resourcecontainers
    | where type == 'microsoft.resources/subscriptions'
    | where subscriptionId == '{0}'" -f $subscriptionId

    $subscriptionDetails = Search-AzGraph -Query $subscriptionGraphQuery

    # Check name availability and select available name
    $connectionName = "er-vhub-to-"+$subscriptionDetails.Name -replace "sub-"

    # Get list of all connections to verify name
    $uri = "https://management.azure.com/subscriptions/8406eed5-3171-437f-90bf-184f698e5fd7/resourceGroups/rg-de-ohg-ats-tf-prod-vhub/providers/Microsoft.Network/virtualHubs/hub-we-prod-01/hubVirtualNetworkConnections?api-version=2023-05-01"
    $allConnections = (Invoke-RestCommand -method "get" -uri $uri).value.name

    # Generate connection name depending on number of connections that are currently deployed for landing zone
    if ($allConnections -contains $connectionName) {
        Write-Verbose  ("Connection name {0} is already in use. Searching for next available name" -f $connectionName) -Verbose
        [string]$numberOfSubConnections = ($allconnections | where {$_ -like "$connectionName*"}).count
        $connectionName = $connectionName+"-"+$numberOfSubConnections.PadLeft(2,"0")
    }
    Write-Verbose  ("New connection name {0}" -f $connectionName) -Verbose
    
    return $connectionName
}