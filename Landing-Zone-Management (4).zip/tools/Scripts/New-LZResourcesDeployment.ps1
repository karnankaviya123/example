
<#
    .SYNOPSIS
    Creates Landing Zone

    .DESCRIPTION
    Creates Landing zone. Includes Validations / Sanity Checks against Azure

    .PARAMETER lzconfigPath
    Mandatory. The lzconfig.json with the fundamental deployment configuration (e.g. Project & Stage)

    .PARAMETER updateMode
    Optional. If true, the deployment is considered to be a Landing Zones Update, in opposite to the Landing Zone Creation.
    This is currently used for two things:
    1) Do not deploy VNet and Hub Connection (Temporary - workaround to avoid destroying subnets on re-deployment)

    .EXAMPLE
    ./tools/Scripts/New-LandingZone.ps1 -lzconfigPath:"lzconfig.json" -WhatIf:$true
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $lzconfigPath,

    [Parameter(Mandatory = $false)]
    [boolean] $updateMode = $false
)

#region helper functions
<#
.SYNOPSIS
Gets next available name for storage account

.DESCRIPTION
Gets next available name for storage account basing on subscription name parameters. By default storage account number is 001, this function will increment it if required.

.PARAMETER project
Required. Name of project. Required to build storage account name

.PARAMETER subscriptionName
Required. Name of subscription where storage account will be deployed

.PARAMETER stage
Required. Stage of subscription. Required to build storage account name

.EXAMPLE
Get-AvailableStorageAccountName -Project "lztstcorp" -Stage "dev" -SubscriptionName "sub-lztstcorp-dev"

#>
function Get-AvailableStorageAccountName {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $project,

        [Parameter(Mandatory = $true)]
        [string] $subscriptionName,

        [Parameter(Mandatory = $true)]
        [string] $stage
    )

    [string]$number = "1"
    [string]$storageAccountName = "st" + $project + $stage + "tfs" + $number.PadLeft(3, '0')
    [string]$resourceGroupName = "rg-" + $project + "-" + $stage + "-tfstate"
    # Fetches the storage account count in given resource group
    $storageAccountCount = (Get-AzStorageAccount -ResourceGroupName $resourceGroupName -ErrorAction 'Ignore').count 
    $subscriptionId = (Get-AzSubscription -SubscriptionName $SubscriptionName -ErrorAction 'Ignore').id
    $uri = "https://management.azure.com/subscriptions/{0}/providers/Microsoft.Storage/checkNameAvailability?api-version=2022-09-01" -f $subscriptionId
    $connection = Get-AzAccessToken -ResourceTypeName ResourceManager
    $authHeader = @{
        'Content-Type'  = 'application/json'
        'Authorization' = 'Bearer ' + $connection.Token
    }
    $body = @{
        "name" = $storageAccountName
        "type" = "Microsoft.Storage/storageAccounts"
    } | ConvertTo-Json

    # If the resource group already have a storage account then script will exit without creating any storage account resource
    if ($storageAccountCount -eq 0) {

        # Check name availability in Azure
        $restMethodResponse = Invoke-RestMethod -Body $body -Method Post -Headers $authHeader -Uri $uri -Verbose

        # If name is not available find next available name
        if (-not $restMethodResponse.nameAvailable) {
            # Search for next available Storage Account name while $checkNameAttempt is less than 5 (check names between 002 and 005)
            $checkNameAttempt = 1
            do {
                $checkNameAttempt++
                $number = $checkNameAttempt.ToString()
                [string]$storageAccountName = "st" + $project + $stage + "tfs" + $number.PadLeft(3, '0')
                $body = @{
                    "name" = $storageAccountName
                    "type" = "Microsoft.Storage/storageAccounts"
                } | ConvertTo-Json

                $restMethodResponse = Invoke-RestMethod -Body $body -Method Post -Headers $authHeader -Uri $uri -Verbose
                if ($restMethodResponse.nameAvailable) {
                    break
                }
            } while ($checkNameAttempt -lt 5)
        }
        # Return storage account name
        return $storageAccountName
    }
}
#endregion

#Read Config
$Config = Get-Content -Raw -Path $lzconfigPath | ConvertFrom-Json -Depth 99 -AsHashtable

$project = $Config.project.ToLower()
$stage = $Config.stage.ToLower()
$context = $Config.context.ToLower()
$number = $Config.number

#Add ccoe_lz_version tag to deployment parameters
$Config.Tag.Add("ccoe_lz_version", "LZv" + $Config.LZVersion)

Write-Verbose "Processing Config: " -Verbose
Write-Verbose ($Config | ConvertTo-Json) -Verbose

#Build Subscription Name
if ($updateMode) {
    $SubscriptionName = Split-Path -Path (Split-Path -Path $lzconfigPath -Parent) -Leaf # using the name of the folder containing the lzconfig.jaon
}
else {
    $SubscriptionName = "sub-" + $project + "-" + $stage

    if ($context -ne '<none>') {
        $subscriptionName = $subscriptionName + "-" + $context
    }

    if ($Config.number -ne '<none>') {
        $number = $Config.number.PadLeft(3, '0')
        $subscriptionName = $subscriptionName + "-" + $number
    }

    Write-Verbose ("Generated subscription name in LZ Resource deployment: {0}" -f $subscriptionName ) -Verbose
}



#region Sanity Checks

# Subscription validation
# -----------------------
# Check if Sub already exists and get ID if
$ExistingSubscriptionId = (Get-AzSubscription -SubscriptionName $SubscriptionName -ErrorAction 'Ignore').id
if (-not $ExistingSubscriptionId) {
    Write-Verbose ("Subscription [{0}] not found. Checking subscription alias [{0}]" -f $SubscriptionName) -Verbose
    $ExistingSubscriptionId = (Get-AzSubscriptionAlias -AliasName $SubscriptionName -ErrorAction 'Ignore').id
}
if (-not $ExistingSubscriptionId) {
    Write-Verbose ("Subscription alias [{0}] not found. Checking second alias [{1}]" -f $SubscriptionName, "alias-$SubscriptionName") -Verbose
    $ExistingSubscriptionId = (Get-AzSubscriptionAlias -AliasName "alias-$SubscriptionName" -ErrorAction 'Ignore').id
}
if ($ExistingSubscriptionId) {
    Write-Verbose "Found subscription [$SubscriptionName], Subscription Id: [$ExistingSubscriptionId]" -Verbose
    Write-Host "##vso[task.setvariable variable=lzSubscriptionId;]$ExistingSubscriptionId"
}
else {
    throw "Subscription [$SubscriptionName] not found in the Management Group [$($Config.MgmtGrId)]"
}

# Address Prefix validation
# -------------------------
$confirmInputObject = @{
    AddressPrefixes = $Config.vnetAddressPrefix
    Verbose         = $true 
    ErrorAction     = 'Stop'
}
if (-not [String]::IsNullOrEmpty($ExistingSubscriptionId)) {
    $confirmInputObject += @{
        vnetRGName             = $Config.ResourceNames.rgVnet.ToLower()
        vnetName               = $Config.ResourceNames.vnetName.ToLower()
        existingSubscriptionId = $ExistingSubscriptionId
    }
}

If (($Config.vnetAddressPrefix -ne '<none>') -and (($Config.MgmtGrId -eq 'mg-corp') -or ($Config.MgmtGrId -eq 'dev-mg-corp') -or ($Config.MgmtGrId -eq 'build-mg-corp') -or ($Config.MgmtGrId -eq 'mg-sap'))) {
    $null = Confirm-VNETAddressPrefix @confirmInputObject
}

# Storage account validation
# -----------------------

$Config.ResourceNames.saName = Get-AvailableStorageAccountName -Stage $stage -Project $project -SubscriptionName $subscriptionName
if ($Config.ResourceNames.saName -eq $null) {
    $Config.ResourceNames.saName = ''
}


#endregion Sanity Checks

# Deploy template for LZ
# ----------------------

If (($Config.MgmtGrId -eq 'mg-corp') -or ($Config.MgmtGrId -eq 'dev-mg-corp') -or ($Config.MgmtGrId -eq 'build-mg-corp') -or ($Config.MgmtGrId -eq 'mg-sap')) {
    $TemplateParameterObject = @{
        parentMgId        = $Config.MgmtGrId
        project           = $project
        stage             = $stage
        context           = $context
        number            = $number
        VNETAddressPrefix = $Config.vnetAddressPrefix
        DNSServers        = $Config.vnetDNSServers
        Tags              = $config.Tag
        skipVNet          = $updateMode
        resourceNames     = $Config.ResourceNames
    }
}
else {
    # remove parameter values before deployment
    $Config.ResourceNames.rgVnet = ''
    $Config.ResourceNames.vnetName = ''

    $TemplateParameterObject = @{
        parentMgId        = $Config.MgmtGrId
        project           = $project
        stage             = $stage
        context           = $context
        number            = $number
        VNETAddressPrefix = ''
        DNSServers        = $Config.vnetDNSServers
        Tags              = $config.Tag
        skipVNet          = $updateMode
        resourceNames     = $Config.ResourceNames
    }

}
if ($updateMode) {
    $DeploymentParams = @{
        DeploymentName          = "LZ-Update-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
        TemplateFile            = "$PSScriptRoot/../.bicep/deployLZResources.bicep"
        location                = "westeurope"
        TemplateParameterObject = $TemplateParameterObject 
        Verbose                 = $true
    }
}
else {
    $DeploymentParams = @{
        DeploymentName          = "LZ-Create-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
        TemplateFile            = "$PSScriptRoot/../.bicep/deployLZResources.bicep"
        location                = "westeurope"
        TemplateParameterObject = $TemplateParameterObject 
        Verbose                 = $true
    }
}


Write-Verbose "Invoke deployment with" -Verbose
Write-Verbose ($DeploymentParams | ConvertTo-Json | Out-String ) -Verbose
Write-Verbose ("The Deployment Name is {0}" -f $DeploymentParams.DeploymentName ) -Verbose

Test-AzSubscriptionDeployment @DeploymentParams 

if ($PSCmdlet.ShouldProcess("Subscription-level deployment for subscription [$SubscriptionName]", "Invoke")) {
    $res = New-AzSubscriptionDeployment @DeploymentParams
    Write-Verbose ($res.Outputs | ConvertTo-Json -Depth 10 | Out-String) -Verbose
    $resources = $res.Outputs | ConvertTo-Json -Depth 10 | Out-String
    
    # Convert the JSON to an object
    $data = ConvertFrom-Json $resources
    
    # Fetch subscription tags
    $subscriptionTags = $data.subscriptionTags.Value
    Write-Host "##vso[task.setVariable variable=SubscriptionTags;]$subscriptionTags"
    
    # Fetch ResourceIDs 
    $resourceValues = $data.PSObject.Properties.Value.Value | Select-Object -Skip 1
    $resourceValues = $resourceValues | Where-Object { $_ -match '\S' }
    Write-Host "##vso[task.setVariable variable=ResourceIDs;]$resourceValues"
}

else {
    New-AzSubscriptionDeployment @DeploymentParams -WhatIf
}