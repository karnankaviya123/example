[CmdletBinding(SupportsShouldProcess = $true)]
param (
    [Parameter(Mandatory = $true,
        HelpMessage = "Group Owner UPN")]
    [string]$groupOwnerUPN,

    [Parameter(Mandatory = $true,
        HelpMessage = "Display name of the group.")]
    [string]$displayName,

    [Parameter(Mandatory = $true,
        HelpMessage = "Subscription Owner UPN")]
    [string]$subscriptionOwnerUPN,

    [Parameter(Mandatory = $true,
        HelpMessage = "AAD Group Name Template")]
    [string]$groupNameTemplate,

    [Parameter(Mandatory = $true,
        HelpMessage = "WhatIf value")]
    [string]$validateOnly
)


function Invoke-RESTCommand {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $method,
        [Parameter(Mandatory = $true)]
        [string] $uri,
        [Parameter(Mandatory = $false)]
        [string] $body,
        [Parameter(Mandatory = $false)]
        [hashtable] $header
    )
    try {
        $inputObject = @(
            '--method', $method,
            '--uri', $uri
        )
        # Build Body
        # ---------
        if ($body) {
            $tmpPath = Join-Path $PSScriptRoot ("REST-$method-{0}.json" -f (New-Guid))
            $body | Out-File -FilePath $tmpPath -Force
            $inputObject += '--body', "@$tmpPath"
        }
        # Build Header
        # -----------
        if (-not $header) {
            $header = @{}
        }
        $compressedHeader = ConvertTo-Json $header -Depth 10 -Compress
        if ($compressedHeader.length -gt 2) {
            # non-empty
            $tmpPathHeader = Join-Path $PSScriptRoot ("REST-$method-header-{0}.json" -f (New-Guid))
            $compressedHeader | Out-File -FilePath $tmpPathHeader -Force
            $inputObject += '--headers', "@$tmpPathHeader"
        }
        # Execute
        # -------
        try {
            $rawResponse = az rest @inputObject -o json 2>&1
            #Write-Verbose  "REST response: $rawResponse" -Verbose
        }
        catch {
            $rawResponse = $_
            #Write-Verbose  "REST error: $rawResponse" -Verbose
        }
        if ($rawResponse.Exception) {
            $rawResponse = $rawResponse.Exception.Message
        }
        # Remove wrappers such as 'Conflict({...})' from the repsonse
        if (($rawResponse -is [string]) -and $rawResponse -match '^[a-zA-Z].+?\((.*)\)$') {
            if ($Matches.count -gt 0) {
                $rawResponse = $Matches[1]
            }
        }
        if ($rawResponse) {
            if (Test-Json ($rawResponse | Out-String) -ErrorAction 'SilentlyContinue') {
                return (($rawResponse | Out-String) | ConvertFrom-Json)
            }
            else {
                return $rawResponse
            }
        }
    }
    catch {
        throw $_
    }
    finally {
        # Remove temp files
        if ((-not [String]::IsNullOrEmpty($tmpPathHeader)) -and (Test-Path $tmpPathHeader)) {
            Remove-item -Path $tmpPathHeader -Force
        }
        if ((-not [String]::IsNullOrEmpty($tmpPath)) -and (Test-Path $tmpPath)) {
            Remove-item -Path $tmpPath -Force
        }
    }
}

function Get-AzureADUserObjectId {
    param (
        [string]$userPrincipalName
    )

    $GraphAPIEndpoint = "https://graph.microsoft.com/v1.0/users/$userPrincipalName"
    $restInputObject = @{
        method = 'GET'
        uri    = $GraphAPIEndpoint
        header = @{
            "Content-Type" = "application/json"
        }
    }

    # List of domains that are used at ALDI. Required to check if UPN exists in AAD
    [System.Collections.ArrayList]$domainNameSuffixes = @(
        "aldi-nord.com",
        "aldi-nord.de",
        "aldi-techhub.pl",
        "aldi.fr",
        "aldi.pl",
        "aldi.be",
        "aldi.nl",
        "aldi.es",
        "aldi.dk",
        "aldi.pt",
        "aldi-imv.de",
        "aldi.lu"
    )

    try {
        # Check if user principal name ends with any domain suffix. "Ext" is ignored to shorten domains list
        if ($domainNameSuffixes.Contains(($userPrincipalName.Split("@")[1]).Replace('ext.',''))) {
            $technicalContactId = Invoke-RESTCommand @restInputObject -ErrorAction Stop
            return $technicalContactId.id
        }
        else {
            Write-Verbose "User [$userPrincipalName] does not exist" -Verbose
            return $null
        }
    }
    catch {
        Write-Verbose "Error: $($_.Exception.Message)" -Verbose
        return $null
    }
}

function Add-AzureADMembersToGroup {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $memberId,

        [Parameter(Mandatory = $true)]
        [string] $groupId,
        
        [Parameter(Mandatory = $false)]
        [string] $validateOnly
    )

    $restUri = "https://graph.microsoft.com/v1.0/groups/$groupId/members"
    $headers = @{
        "Content-Type"  = "application/json"
    }

    # Check if the member already exists in the group
    $existingMember = Invoke-RESTCommand $restUri -Method 'GET' -Header $headers -ErrorAction SilentlyContinue

    $foundUser = $existingMember.value | Where-Object { $_.id -eq $memberId }

    if ($foundUser) {
        Write-Verbose "Member already exists in the group: $groupID. Skipping the addition of the member to group." -Verbose
    } 
    else {
        Write-Verbose "Member not found in Group: $groupID. Adding the $memberId to group." -Verbose

        $body = @{
            "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$memberId"
        }   
        $ref = '$ref'
        $uri = "https://graph.microsoft.com/v1.0/groups/$groupId/members/$ref"

        If ($validateOnly -ne $true) {
            $response = Invoke-RESTCommand $uri -Method 'POST' -Header $headers -Body ($body | ConvertTo-Json)

            if (-not [String]::IsNullOrEmpty($response.error)) {
                $errorMsg = $response.error.message
                if ($errorMsg -match "One or more added object references already exist for the following modified properties: ") {
                    Write-Verbose "Member already exists in the group: $groupId, groupName:$groupName. Skipping the addition of the member to the group." -Verbose
                    $global:lastExitCode = 0
                } else {
                    Write-Verbose "An error occurred while adding the member to the group: $($response.Exception.Message)" -Verbose
                }
            } else {
                Write-Verbose "Member $memberId added to the group $groupId successfully." -Verbose
            }
        }
    }
}

function New-AzureGroup {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $displayName,
        [Parameter(Mandatory = $true)]
        [string] $technicalContactId,
        [Parameter(Mandatory = $true)]
        [string] $subscriptionOwnerId,
        [Parameter(Mandatory = $true)]
        [string] $validateOnly, 
        [Parameter(Mandatory = $true)]
        [string] $groupNameTemplate 
    )

    $groupRoles = @('Reader', 'Contributor', 'Owner')
    $groupNamesToDisplay = New-Object System.Collections.ArrayList

    # Display group names for operations team, so it will be easier to find them in AAD

    $groupNamesToDisplay.Add("AAD Group names:") | Out-null

    $groupNamesArray = @()

    $groupNamesArray += $displayName

    foreach ($roleName in $groupRoles) {
        $groupNamesToDisplay.Add("`n$groupNameTemplate" -f $roleName) | Out-null
        $groupName = $groupNameTemplate -f $roleName
        $groupNamesArray += $groupName
    }
   
    Write-Verbose "Notification Group name: " -Verbose
    Write-Verbose "$displayName" -Verbose
    Write-Verbose "$groupNamesToDisplay`n`n" -Verbose

    #Creating hashtable to store group Ids
    [System.Collections.Hashtable]$groupIds = [ordered]@{}

    # Create groups

    foreach ($groupName in $groupNamesArray) {
    
        Write-Verbose "Check if group '$groupName' already exists" -Verbose
        
        $restUri = 'https://graph.microsoft.com/v1.0/groups'
        $query = "?`$filter=displayName eq '$groupName'"
        $graphApiEndpoint = "$restUri$query"

        $restInputObject = @{
            method = 'GET'
            uri    = '"{0}"' -f $graphApiEndpoint
            header = @{
                "Content-Type" = "application/json"
            }
        }

        $response = Invoke-RESTCommand @restInputObject -ErrorAction SilentlyContinue

        if ($response.value.Count -gt 0) {
            $existingGroupId = $response.value[0].id
            Write-Verbose "Group already exists: $groupID" -Verbose
            # Access and display properties from the $response object
            $existingGroup = $response.value[0]
            $existingGroupDisplayName = $existingGroup.displayName
            $existingGroupDescription = $existingGroup.description
            Write-Host "ID: $existingGroupId"
            Write-Host "DisplayName: $existingGroupDisplayName"
            if ($groupName -notlike "*O365*") {
               # Add existing group to output variable
               $groupIds.Add($existingGroup.displayName, $existingGroupId)
            }
        } else {
            $owners = [System.Collections.ArrayList]@()
            if ($technicalContactId -eq $subscriptionOwnerId) {
                $owners.Add('https://graph.microsoft.com/v1.0/users/{0}/' -f $technicalContactId) | Out-null
            } else {
                $owners.Add('https://graph.microsoft.com/v1.0/users/{0}/' -f $technicalContactId) | Out-null
                $owners.Add('https://graph.microsoft.com/v1.0/users/{0}/' -f $subscriptionOwnerId) | Out-null
            }

            if ($groupName -like "*O365*") {
                # Create mail-enabled group
                Write-Verbose "Creating mail enabled group: $groupName" -Verbose
                $body = @{
                    'displayName'        = '{0}' -f $groupName
                    'description'        = '{0}' -f $groupName
                    'groupTypes'         = @("Unified")
                    'isAssignableToRole' = 'false'
                    'mailNickname'       = '{0}' -f $groupName
                    'mailEnabled'        = 'true'
                    'securityEnabled'    = 'false'
                    'owners@odata.bind'  = $owners
                    'members@odata.bind' = $owners
                }

                $restInputObject = @{
                    method = 'POST'
                    uri    = '"{0}"' -f $restUri
                    header = @{
                        "Content-Type" = "application/json"
                    }
                    body   = ConvertTo-Json $body -Depth 10 -Compress
                }

                $group = Invoke-RESTCommand @restInputObject -ErrorAction SilentlyContinue
                $group = $group | ConvertTo-Json -Depth 99 | ConvertFrom-JSON

                if (-not [String]::IsNullOrEmpty($group.error)) {
                    $errorMsg = $group.error.message
                    if ($errorMsg -match "Another object with the same value for property mailNickname already exists") {
                        Write-Verbose "Group '$groupName' already exists." -Verbose
                        $global:lastExitCode = 0
                    } else {
                        Write-Error ('Failed to create mail enabled [{0}] details because of [{1} - {2}].' -f $groupName, $group.error.code, $group.error.message)
                    }
                } else {
                    Write-Verbose ("Main enabled group successfully created [Name: {0} Id: {1}]." -f $group.displayName, $group.id) -Verbose           
                }
            } else {
                # Create AAD group
                Write-Verbose "Creating security group: $groupName" -Verbose

                $body = @{
                    'displayName'        = '{0}' -f $groupName
                    'description'        = '{0}' -f $groupName
                    'mailNickname'       = '{0}' -f $groupName
                    'mailEnabled'        = 'false'
                    'securityEnabled'    = 'true'
                    'owners@odata.bind'  = $owners
                    'members@odata.bind' = $owners
                }

                $restInputObject = @{
                    method = 'POST'
                    uri    = '"{0}"' -f $restUri
                    header = @{
                        "Content-Type" = "application/json"
                    }
                    body   = ConvertTo-Json $body -Depth 10 -Compress
                }

                $group = Invoke-RESTCommand @restInputObject -ErrorAction SilentlyContinue
                $group = $group | ConvertTo-Json -Depth 99 | ConvertFrom-JSON

                if (-not [String]::IsNullOrEmpty($group.error)) {
                    $errorMsg = $group.error.message
                    if ($errorMsg -match "Another object with the same value for property mailNickname already exists") {
                        Write-Verbose "Group '$groupName' already exists." -Verbose
                        $global:lastExitCode = 0
                    } else {
                        Write-Error ('Failed to create security group [{0}] details because of [{1} - {2}].' -f $groupName, $group.error.code, $group.error.message)
                    }
                } else {
                    Write-Verbose ("Security group successfully created [Name: {0} Id: {1}]." -f $group.displayName, $group.id) -Verbose
                    # Adding new Security group ID to output variable
                    $groupIds.Add($group.displayName, $group.id)

                }
            }
        }
    }
    return $groupIds
}


# Get Technical Contact ID and subscription owner IDs
$technicalContactId = Get-AzureADUserObjectId -userPrincipalName $groupOwnerUPN
$subscriptionOwnerId = Get-AzureADUserObjectId -userPrincipalName $subscriptionOwnerUPN

# Create new Azure Groups and add owners and members
$groupIdsResult = New-AzureGroup -displayName $displayName -technicalContactId $technicalContactId -subscriptionOwnerId $subscriptionOwnerId -validateOnly $validateOnly -groupNameTemplate $groupNameTemplate

Write-Verbose  "Group names and IDs" -Verbose
$groupIdsResult | Format-Table -AutoSize

# Group Object ID of AZR.AA.ALL.O365.allprojects.Notification Notification Group
$groupId = "f955d9f8-94d4-472e-9859-402b9d96a86a"

# Add owner and technical contact to "AZR.AA.ALL.O365.allprojects.Notification" group
Write-Verbose  "Adding contacts to AZR.AA.ALL.O365.allprojects.Notification group" -Verbose
Add-AzureADMembersToGroup -memberId $technicalContactId -groupId $groupId -validateOnly $validateOnly 
Add-AzureADMembersToGroup -memberId $subscriptionOwnerId -groupId $groupId -validateOnly $validateOnly 

Write-Output ('##vso[task.setVariable variable=groupIds;]{0}' -f ($groupIdsResult  | ConvertTo-JSON -Depth 100 -Compress))
