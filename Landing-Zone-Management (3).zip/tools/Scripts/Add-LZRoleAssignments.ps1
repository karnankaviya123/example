
<#
    .SYNOPSIS
    Creates 3 RBAC assignments

    .DESCRIPTION
    Creates 3 RBAC assignments with default roles: Reader, Contributor, Owner

    .PARAMETER groupNameTemplate
    Mandatory. Template that will be filled out to get group names

    .EXAMPLE
    ./tools/Scripts/Add-LZRoleAssignments.ps1 -groupNameTemplate "AZR.WW.MST.contoso.sub.DEV.{0}" -WhatIf:$true
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $groupNameTemplate
)


@(
    "Reader",
    "Owner",
    "Contributor"
) | % {
    $groupName = $groupNameTemplate -f $_
    $roleName = $_

    # Check if group exists and assign roles
    Write-Verbose "Processing role assignment for group '$groupName'" -Verbose

    $group = Get-MgGroup -Filter "DisplayName eq '$groupName'"
    if ($group) {
        Write-Verbose  "Group already exists: $($group.Id)" -Verbose

        # Assign role

        Write-Verbose  "Checking existing role assigments" -Verbose
            
        $assignment = Get-AzRoleAssignment -ObjectId $group.Id | ?{ $_.RoleDefinitionName -Eq $roleName } 

        if ($assignment) {
            Write-Verbose  "Role assignment already exists: '$roleName'" -Verbose
        } else {
            if ($PSCmdlet.ShouldProcess("Assigning '$roleName' role to Group: $($group.DisplayName)", "Invoke")) {
                Write-Verbose  "Assigning '$roleName' role to Group: $($group.Id)" -Verbose
                $assignment = New-AzRoleAssignment -ObjectId $($group.Id) -RoleDefinitionName $roleName
            } else {
                Write-Verbose  "Would assign '$roleName' role to Group: $($groupName)" -Verbose
            }   
        }

        if ($assignment) {
            $assignment | Format-List    
        }
    }
}





