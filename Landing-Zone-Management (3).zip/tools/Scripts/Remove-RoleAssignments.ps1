
<#
    .SYNOPSIS
    Deletes 3 RBAC assignments

    .DESCRIPTION
    Deletes 3 RBAC assignments with default roles: Reader, Contributor, Owner

    .PARAMETER groupNameTemplate
    Mandatory. Template that will be filled out to get group names

    .EXAMPLE
    ./tools/Scripts/RemoveRoleAssignments.ps1 -groupNameTemplate "WW.MST.contoso.sub.DEV.{0}" -WhatIf:$true
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $groupNameTemplate
)


@(
    "Reader",
    "Owner",
    "Contributor"
) | % {
    $groupName = $groupNameTemplate -f $_
    $roleName = $_

    # Check if group exists and assign roles
    Write-Verbose "Processing role assignment for group '$groupName'" -Verbose

    $group = Get-MgGroup -Filter "DisplayName eq '$groupName'"
    if ($group) {
        Write-Verbose  "Group exists: $($group.Id)" -Verbose

        # Assign role

        Write-Verbose  "Checking existing role assigments" -Verbose
            
        $assignment = Get-AzRoleAssignment -ObjectId $group.Id | ? { $_.RoleDefinitionName -Eq $roleName } 

        if ($assignment) {
            Write-Verbose  "Remove role assignment: '$roleName'" -Verbose
            
            if ($PSCmdlet.ShouldProcess("Removing '$roleName' role from Group: $($group.DisplayName)", "Invoke")) {
                Write-Verbose  "Removing '$roleName' role from Group: $($group.Id)" -Verbose
                Remove-AzRoleAssignment -ObjectId $($group.Id) -RoleDefinitionName $roleName
                
            }
            else {
                Write-Verbose  "Would remove '$roleName' role from Group: $($groupName)" -Verbose
            }   
        }
        else {
            Write-Verbose  "Role assignment doesnt exist: '$roleName' role to Group: $($groupName)" -Verbose

        }
    }
}

