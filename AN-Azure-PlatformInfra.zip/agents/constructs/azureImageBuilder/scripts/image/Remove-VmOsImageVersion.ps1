﻿<#
.SYNOPSIS
Delete any excess image versions inside the provided VM image definition. The rule is to keep the 10 latest image versions in 
the VM image definiton, if they require to rollback.

.DESCRIPTION
All image versions will be considered from either Linux or Windows Image Definitions. 
It is sorted by the published dates of each image version, to then be deleted in the order, leaving the last 10 elements from 
being deleted.

.PARAMETER resourceGroupName
Mandatory. The resource group name in which the Compute Gallery sits

.PARAMETER computeImageGalleryName
Mandatory. The Compute gallery name which holds both Linux and Windows VM image definitions

.PARAMETER vmImageDefinitionName
Mandatory. The VM image definition name selected to delete the excess image versions.

.EXAMPLE
$resourceGroupName = rg-ccoe-prd-weu-vmss-01
$computeImageGalleryName = aibgallery002
$vmImageDefinitionName = linux-sid-prod-001
Remove-VmOsImageVersion -resourceGroupName 'rg-ccoe-prd-weu-vmss-01' -computeImageGalleryName 'aibgallery002' -vmImageDefinitionName 'linux-sid-prod-001'

Will delete the following: (verbosed to show what is being deleted)

    '0.25462.31207',
    '0.25468.42096',
    '0.25469.4999',
    '0.25494.12881',
    '0.25532.47152'

As a result, the VM image definiton name 'linux-sid-prod-001' will hold the 10 latest image versions built from the Azure Image Builder pipeline.
#>

function Remove-VmOsImageVersion  {

    [CmdletBinding()]
    [OutputType('String')]
    param (
        [Parameter(Mandatory)]
        [string] $resourceGroupName,

        [Parameter(Mandatory)]
        [Object] $computeImageGalleryName,

        [Parameter(Mandatory)]
        [Array] $arrayOfImageDefinitionNames
    )

    # Iterate through the list of image definition names
    foreach ($ImageDefinitionName in $arrayOfImageDefinitionNames) {
        Write-Verbose "Checking through the current vm image definition: $ImageDefinitionName" -Verbose
        # For the selected image definition name, create an object array of all image versions with their name and published date 
        $imagegalleryinfo = Get-AzGalleryImageVersion -GalleryName $computeImageGalleryName -ResourceGroupName $resourceGroupName -GalleryImageDefinitionName $ImageDefinitionName | Select-Object -Property Name -ExpandProperty PublishingProfile | Sort-Object -Property PublishedDate | Select-Object -Property Name, PublishedDate
        
        # Output all the image gallery info, if required for troubleshooting
        # Write-Verbose ($imagegalleryinfo | ConvertTo-Json | Out-String) -Verbose
        
        # Iterating through the object array, deleting the all the image versions except for the latest 10 image versions within that image definition
        for ($i = 0; $i -lt $imagegalleryinfo.Length - 10; $i++) {            
            # Break from the for loop, if there are 5 or less image versions.
            if ($imagegalleryinfo.Length -lt 11) {
                Write-Verbose "Length is equal or less than 10. No need for removal." -Verbose
                break
            }
            Write-Verbose "Deleting current vm image definition version: $($imagegalleryinfo[$i]).name from $ImageDefinitionName" -Verbose
            Remove-AzGalleryImageVersion -GalleryName $computeImageGalleryName -GalleryImageDefinitionName $ImageDefinitionName -Name $($imagegalleryinfo[$i]).name -ResourceGroupName $resourceGroupName -force -AsJob
        }
    }

    return
}