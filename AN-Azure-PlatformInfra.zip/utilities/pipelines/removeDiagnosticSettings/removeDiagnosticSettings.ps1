

function Remove-AzDiagnosticSettingIfNotFromPolicy {

    [CmdletBinding(SupportsShouldProcess)] #TODO
    param (
        [Parameter(Mandatory)]
        [string] $managementGroupId,

        [Parameter(Mandatory = $false)]
        [string] $lawName = "log-we-prod-logmanagementworkspace",

        [Parameter(Mandatory = $false)]
        [string] $diagSettingsName = "setbypolicy",

        [Parameter(Mandatory = $false)]
        [bool] $simulateOnly = $true #,
    )

    Write-Host "Starting to remove diagnostic settings from resources in management group: $managementGroupId"
    Write-Host "Diagnostic settings with the a different name than: $diagSettingsName and Log Analytics workspace: $lawName will be removed"
    Write-Host "Simulation is set to: $simulateOnly"

    # Get all subscriptions in the management group
    $allSubsFromMg = Get-AzManagementGroupSubscription -GroupId  $managementGroupId

    Write-Verbose ('Found [{0}] subscriptions in the MG [{1}]' -f $allSubsFromMg.Count, $managementGroupId ) -Verbose

    $lockedResources = @()

    # Loop through all subscriptions in the management group
    foreach ($oneSub in $allSubsFromMg) {

        Write-Host "Checking: $($oneSub.DisplayName)"
        # Set the context to the subscription
        Set-AzContext $oneSub.id.Split('/')[-1] | Out-Null

        # Get all Azure resources
        $allResources = Get-AZResource
    
        # Add all storage account children to the list of resources to check for diagnostic settings
        $allResourcesWithSAChildren = @()
        foreach ($oneResource in $allResources) {
            if ( $oneResource.resourcetype -eq "Microsoft.Storage/storageAccounts") {
                $allResourcesWithSAChildren += "$($oneResource.ResourceId)/blobServices/default"
                $allResourcesWithSAChildren += "$($oneResource.ResourceId)/fileServices/default"
                $allResourcesWithSAChildren += "$($oneResource.ResourceId)/queueServices/default"
                $allResourcesWithSAChildren += "$($oneResource.ResourceId)/tableServices/default"
            }
            $allResourcesWithSAChildren += $oneResource.ResourceId
        }

        $allRemovedDiagSettings = @{}

        # Get all Azure resources which have Diagnostic settings enabled and configured
        foreach ($oneResource in $allResourcesWithSAChildren) {
            Write-Host $oneResource
            # Get all diagnostic settings for the resource
            $azDiagSettings = Get-AzDiagnosticSetting -ResourceId  $oneResource `
                -WarningAction SilentlyContinue -ErrorAction SilentlyContinue | Where-Object { $null -ne $_.Id }

            $lockInfo = Get-AzResourceLock -Scope $oneResource
            if ($lockInfo) {
                Write-Warning "Resource lock found, skipping the resource"
                $lockedResources += $oneResource
                continue
            }

            # Loop through all diagnostic settings for the resource
            foreach ($azDiag in $azDiagSettings) {

                If ($azDiag.WorkspaceId) {
                    [string]$logAnalytics = $azDiag.WorkspaceId.Split('/')[-1]

                    # Check if the Log Analytics workspace is the correct one and the name is different then from policy and if not, delete the diagnostic setting
                    if ($logAnalytics -eq $lawName -and $azDiag.Name -ne $diagSettingsName) {

                        Write-Host "NEED TO DELETE DIAGNOSTIC SETTING: --- " + $azDiag.Name + " --- FOR RESOURCE: --- " + $oneResource + " ---"    
                        if ($simulateOnly) {
                            Remove-AzDiagnosticSetting -Name $azDiag.Name -ResourceId $oneResource -WhatIf -WarningAction SilentlyContinue
                        }
                        else {
                            Remove-AzDiagnosticSetting -Name $azDiag.Name -ResourceId $oneResource -WarningAction SilentlyContinue -Confirm:$false
                        }
                        $allRemovedDiagSettings.Add($oneResource, $azDiag.Name )
                    }
                    #region DEBUGGING
                    # Check if the Log Analytics workspace is the correct one and the name is the same as from policy for debugging output
                    # elseif ($logAnalytics -eq $lawName -and $azDiag.Name -eq $diagSettingsName) {
                    #     #"OK --- " + $azDiag.Name + " --- FOR RESOURCE: --- " + $oneResource + " ---"
                    # }
                    #endregion
                }
            }
        }
    }

    Write-Verbose ('Locked (skipped) resources:') -Verbose
    Write-Verbose ($lockedResources | ConvertTo-Json | Out-String) -Verbose

    return $allRemovedDiagSettings
}
