<#
.SYNOPSIS
Delete all VHD and JSON blobs, excluding the latest 2 Blob files present in the blob storage account container.

.DESCRIPTION
All blobs will be considered of the OS type provided, then sorted against it's time properties. 
'Latest' is calculated based on the time of creation property.
Once sorted, all blobs are deleted, except for the last 2 Blob files.

.PARAMETER blobs
Mandatory. The Blobs to consider

.PARAMETER osType
Mandatory. The type of Operating System (either Windows or Linux)

.PARAMETER storageContainerName
Mandatory. The Storage Account Container containing the blobs

.PARAMETER storageAccountName
Mandatory. The Storage Account containing the blobs

.EXAMPLE
$blobs = @(
    'Microsoft.Compute/Images/images/agent-lin-osDisk.1a455362-b03f-4d06-9d3e-07f92e5013df.vhd',
    'Microsoft.Compute/Images/images/agent-lin-osDisk.359e657c-f1d0-481f-a0f7-57324b9fc4ea.vhd',
    'Microsoft.Compute/Images/images/agent-lin-osDisk.a24b6e93-80ae-49eb-beea-1769349e7262.vhd',
    'Microsoft.Compute/Images/images/agent-lin-osDisk.e4a9c0ac-8720-408e-8b94-7e5c7d180c09.vhd',
    'Microsoft.Compute/Images/images/agent-lin-vmTemplate.e4a9c0ac-8720-408e-8b94-7e5c7d180c09.json'
)
Remove-OldOsBlob -blobs $blobs -ImageStorageAccountContainerName 'system' -ImageStorageAccountName 'myStorageAccount'

Will delete the following:

    'Microsoft.Compute/Images/images/agent-lin-osDisk.1a455362-b03f-4d06-9d3e-07f92e5013df.vhd',
    'Microsoft.Compute/Images/images/agent-lin-osDisk.359e657c-f1d0-481f-a0f7-57324b9fc4ea.vhd',
    'Microsoft.Compute/Images/images/agent-lin-osDisk.a24b6e93-80ae-49eb-beea-1769349e7262.vhd',

This is because it is a VHD and least recent than the others (based on the properties timestamp).
#>

function Remove-OldOSBlob {

    [CmdletBinding()]
    [OutputType('String')]
    param (
        [Parameter(Mandatory)]
        [Object] $blobs,

        [Parameter(Mandatory)]
        [string] $storageContainerName,

        [Parameter(Mandatory)]
        [string] $storageAccountName
    )
    
    # Sort out the blob list from oldest to latest, as an object array.
    $listSorted = $blobs | Sort-Object -Property { [System.DateTime]::ParseExact($_.properties.creationTime, "MM/dd/yyyy HH:mm:ss", $null) } | Select name

    # Remove all the oldest blobs, except for the latest 2 blobs in the container.
    Remove-ArrayElements -fileArray $listSorted -storageContainerName $storageContainerName -storageAccountName $storageAccountName -v

    return
}

function Remove-ArrayElements {
    param(
        [parameter(Mandatory)]
        [array]$fileArray, # Array holding each blob stored in the given storage blob container 

        [Parameter(Mandatory)]
        [string] $storageContainerName,

        [Parameter(Mandatory)]
        [string] $storageAccountName
    )

    $ctx = New-AzStorageContext -StorageAccountName $storageAccountName -UseConnectedAccount

    for ($i = 0; $i -lt $fileArray.Length - 2; $i++) {
        Write-Verbose "Deleting current blob: $fileArray[$i]].name " -Verbose
        Remove-AzStorageBlob -Blob $fileArray[$i].name -Container $storageContainerName -Context $ctx
    }
    return 
}