# Custom software installation script

# Use choco to install Terragrunt
Write-Verbose "Install Terragrunt" -Verbose
choco install terragrunt

Write-Verbose "Test Terragrunt installation" -Verbose
terragrunt --version