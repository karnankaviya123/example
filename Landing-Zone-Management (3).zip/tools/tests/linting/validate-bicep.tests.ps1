Write-Host  "##[group]Start Bicep Pester Tests"
$LinterResults = @()
$bicepCandidates = Get-ChildItem -Recurse -File -Include '*.bicep'
foreach ($bicepfile in $bicepCandidates) {
    $LinterResults += $(bicep build $bicepfile 2>&1).Exception.Message
}

# rather quick and dirty, we should really iterate through the errors found instead
Describe "Bicep" {
    foreach ($Bicepfile in $bicepCandidates) {
        Context "$($Bicepfile.FullName)" {
            It "Build Errors should be empty" -TestCases @{LinterResults = $LinterResults | Select-String -SimpleMatch $Bicepfile.FullName} {
                param($LinterResults)
                $LinterResults | Should -BeNullOrEmpty
            }
        }
    }
}

Write-Host  "##[endgroup]"
