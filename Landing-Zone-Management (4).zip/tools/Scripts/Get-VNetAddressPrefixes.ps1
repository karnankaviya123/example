
function Get-VNetAddressPrefixes {
    <#
    .SYNOPSIS
    Get virtual network address range

    .DESCRIPTION
    Get virtual network address range using Graph

    .PARAMETER virtualNetworkResourceId
    Required. Virtual Network resource ID

    .EXAMPLE
    Get-VNetAddressPrefixes -virtualNetworkResourceId "/subscriptions/<subscriptionId>/resourceGroups/<vnetRGname>/providers/Microsoft.Network/virtualNetworks/<vnetname>"
    #>

    [CmdletBinding()]
    param (
        [parameter(mandatory = $true)]
        [string] $virtualNetworkResourceId
    )

    # VNet graph query
    $vNetGraphQuery = "resources 
    | where type == 'microsoft.network/virtualnetworks'
    | where id == '{0}'" -f $virtualNetworkResourceId

    $virtualNetwork = Search-AzGraph -Query $vNetGraphQuery -First 1000

    return $virtualNetwork.properties.addressSpace.addressPrefixes

}