﻿<#
.SYNOPSIS
Remove a compute image matching the given prefix in the given resource group

.DESCRIPTION
Remove a compute image matching the given prefix in the given resource group

.PARAMETER ResourceGroupName
Required. The resource group name the compute image is deployed into

.PARAMETER ComputeImagePrefix
Optional. The prefix of the compute image to remove.

.EXAMPLE
Remove-ComputeImage -ResourceGroupName 'My-RG' -ComputeImagePrefix 'img-ccoe-'

Search and remove the compute image with prefix 'img-ccoe-' and its generated resource group 'My-RG'
#>
function Remove-ComputeImage {

    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,

        [Parameter(Mandatory = $false)]
        [string] $ComputeImagePrefix = 'img-ccoe-'
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Install required modules
        $currentVerbosePreference = $VerbosePreference
        $VerbosePreference = 'SilentlyContinue'
        $requiredModules = @(
            'Az.Resources'
        )
        foreach ($moduleName in $requiredModules) {
            if (-not ($installedModule = Get-Module $moduleName -ListAvailable)) {
                Install-Module $moduleName -Repository 'PSGallery' -Force -Scope 'CurrentUser'
                if ($installed = Get-Module -Name $moduleName -ListAvailable) {
                    Write-Verbose ('Installed module [{0}] with version [{1}]' -f $installed.Name, $installed.Version) -Verbose
                }
            } else {
                Write-Verbose ('Module [{0}] already installed in version [{1}]' -f $installedModule[0].Name, $installedModule[0].Version) -Verbose
            }
        }
        $VerbosePreference = $currentVerbosePreference
    }

    process {
        [array] $computeImageResources = (Search-AzGraph -Query "Resources | where resourceGroup == '$ResourceGroupName' | where name startswith '$ComputeImagePrefix'")
        Write-Verbose ('Found [{0}] Compute Images to remove.' -f $computeImageResources.Count)

        foreach ($imageTemplateResource in $computeImageResources) {
            if ($PSCmdlet.ShouldProcess('Compute Image [{0}]' -f $imageTemplateResource.Name, 'Remove')) {
                $null = Remove-AzResource -ResourceId $imageTemplateResource.id -Force
                Write-Verbose ('Removed Compute Image [{0}]' -f $imageTemplateResource.id) -Verbose
            }
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }
}
