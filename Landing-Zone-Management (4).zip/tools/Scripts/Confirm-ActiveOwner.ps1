<#
    .SYNOPSIS
    Checks if Owner is active 

    .DESCRIPTION
    Checks if Owner is active 

    .PARAMETER 


    .EXAMPLE
    ./tools/Scripts/Confirm-ActiveOwner.ps1 -managementGroupId "mgID"
#>

function Confirm-ActiveOwner {
    [CmdletBinding()]
    param (
        [parameter(Mandatory = $true)]
        [string] $managementGroupId
    )


    Write-Verbose ("managementGroupName: [{0}]" -f $managementGroupId) -Verbose
    $DisabledUsers = Get-MgUser -Filter 'accountEnabled eq false' -All


    $ResourceGraphQuery = "resourcecontainers
    | where type == 'microsoft.resources/subscriptions'
    | where properties.managementGroupAncestorsChain[1].name=~'{0}'
    | project name, subscriptionId, tags['ccoe_owner'], tags['ccoe_technicalcontact'], properties.managementGroupAncestorsChain[1].name" -f $managementGroupId
    $subInfo = Search-AzGraph -Query $ResourceGraphQuery

 
    foreach ($sub in $subInfo) {
        $UserPrincipalName = $sub.tags_ccoe_owner
        $UserPrincipalNameTechnicalContact = $sub.tags_ccoe_technicalcontact
        $Owner = Get-MgUser -Filter "UserPrincipalName eq '$UserPrincipalName'"
        $TechnicalContact  = Get-MgUser -Filter "UserPrincipalName eq '$UserPrincipalNameTechnicalContact'"
        if ($Owner.id) {
            foreach ($user in $DisabledUsers) {
                if ($user.id -eq $Owner.id) {
                
                    Write-Verbose ("Owner is disabled: [{0}] Id: [{1}] sub name: [{2}] sub id: [{3}]" -f $Owner.displayName, $Owner.id, $sub.name, $sub.subscriptionId ) -Verbose
                
                }
            }
        
        }
        else {
            Write-Verbose ("Owner is empty [{0}]  sub name: [{1}] sub id: [{2}] " -f $sub.tags_ccoe_owner, $sub.name, $sub.subscriptionId) -Verbose
        }
        if ($TechnicalContact.id) {
            foreach ($user in $DisabledUsers) {
                if ($user.id -eq $TechnicalContact.id) {
                
                    Write-Verbose ("Technical Contact is disabled: [{0}] Id: [{1}] sub name: [{2}] sub id: [{3}]" -f $TechnicalContact.displayName, $TechnicalContact.id, $sub.name, $sub.subscriptionId ) -Verbose
                
                }
            }

        }
        else {
            Write-Verbose ("Technical Contact is empty [{0}]  sub name: [{1}] sub id: [{2}] " -f $sub.tags_ccoe_technicalcontact, $sub.name, $sub.subscriptionId) -Verbose
        }
    }
}
