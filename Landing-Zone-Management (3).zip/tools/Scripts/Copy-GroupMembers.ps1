
<#
    .SYNOPSIS
    Creates 3 Azure AD Groups for default permissions set

    .DESCRIPTION
    Creates 3 Azure AD Groups for  default roles: Reader, Contributor, Owner

    .PARAMETER groupNameTemplate
    Mandatory. Template that will be filled out to get group names

    .EXAMPLE
    ./tools/Scripts/Create-LZGroups.ps1 -groupNameTemplate "AZR.WW.MST.contoso.sub.DEV.{0}" -WhatIf:$true
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $groupNameTemplate,
    [string] $groupNameTemplateAD
)
# $allGroups = Get-AzureADGroup -All $true
# $securityGroups = $allGroups | Where-Object {$_.DisplayName -eq $securityGroupName}
# $notificationGroup = $allGroups | Where-Object {$_.DisplayName -eq $NotificationGroupName}


# $groupMembers = Get-AzureADGroup -ObjectId $group.ObjectId | Get-AzureADGroupMember

$groupRoles = @('Reader', 'Contributor', 'Owner')
$groupNamesToDisplay = New-Object System.Collections.ArrayList
$groupNamesToDisplayAD = New-Object System.Collections.ArrayList
$groupIdToDisplayAD = New-Object System.Collections.ArrayList
#newList = [System.Collections.ArrayList]::new()
#(Get-AzureADGroupMember -ObjectId xxxx -All $true) | ForEach-Object {Add-AzureADGroupMember -ObjectId xxxx -RefObjectId $_.ObjectID}  
# Display group names for operations team, so it will be easier to find them in AAD
$groupNamesToDisplay.Add("Group names:") | Out-null

#(Get-MgGroup -Filter "DisplayName eq 'WW.MST.lztstonline.sub.DEV.Contributor'").Id
foreach ($roleName in $groupRoles) {

    $groupNameAAD = ("$groupNameTemplate" -f $roleName)
    $groupNameAD = ("$groupNameTemplateAD" -f $roleName)
    $groupAD = (Get-MgGroup -Filter "DisplayName eq '$groupNameAD'").Id
    $groupAAD = (Get-MgGroup -Filter "DisplayName eq '$groupNameAAD'").Id

    $membersADGroup = (Get-MgGroupMember -GroupId $groupAD ).Id
    $membersAADGroup = (Get-MgGroupMember -GroupId $groupAAD).Id


    if ($membersAADGroup.count -gt 0) {
        Write-Verbose "members of AAD group $groupNameAAD :" -Verbose
        foreach ($member in $membersAADGroup) {
            Write-Verbose "$member" -Verbose
        }
        if ($membersADGroup.count -gt 0) {
            Write-Verbose "members of AD group $groupNameAD :" -Verbose
            foreach ($memberAD in $membersADGroup) {
                Write-Verbose "$memberAD" -Verbose
            }
            foreach ($member in $membersADGroup) {
                If (-not ($membersAADGroup -Contains $member)) {
                    Write-Verbose "Adding AD group member to AAD group: $member" -Verbose
                    if ($PSCmdlet.ShouldProcess("Adding AD group member to AAD group: $member", "Invoke")) {
                        New-MgGroupMember -GroupId $groupAAD -DirectoryObjectId $member
                    }
                    else {
                        Write-Verbose "WhatIf: Adding AD group member to AAD group: $member"
                    }
    
                    
                }
                else {
                    Write-Verbose "User is already in the group: $member" -Verbose
                }
            }


        }        
        else {
            Write-Verbose "AD Group $groupNameAD is empty" -Verbose
        }

    }
    else {
        Write-Verbose "AAD Group $groupNameAAD is empty" -Verbose
        if ($membersADGroup.count -gt 0) {
            Write-Verbose "members of AD group $groupNameAD :" -Verbose
            foreach ($memberAD in $membersADGroup) {
                Write-Verbose "$memberAD" -Verbose
            }
            foreach ($member in $membersADGroup) {
                If (-not ($membersAADGroup -Contains $member)) {
                    Write-Verbose "Adding AD group member to AAD group: $member" -Verbose
                    if ($PSCmdlet.ShouldProcess("Adding AD group member to AAD group: $member", "Invoke")) {
                        New-MgGroupMember -GroupId $groupAAD -DirectoryObjectId $member
                    }
                    else {
                        Write-Verbose "WhatIf: Adding AD group member to AAD group: $member"
                    }
    
                    
                }
                else {
                    Write-Verbose "User is already in the group: $member" -Verbose
                }
            }


        }        
        else {
            Write-Verbose "AD Group $groupNameAD is empty" -Verbose
        }
        
    }
    $groupNamesToDisplay.Add("`n$groupNameTemplate" -f $roleName) | Out-null
    $groupNamesToDisplayAD.Add("`n$groupNameTemplateAD" -f $roleName) | Out-null

}




Write-Verbose "$groupNamesToDisplay`n`n" -Verbose
Write-Verbose "$groupNamesToDisplayAD`n`n" -Verbose



