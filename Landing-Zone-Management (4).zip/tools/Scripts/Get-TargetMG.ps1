<#
.SYNOPSIS
Gets target Management Group

.DESCRIPTION
Gets target Management Group basing on input parameters

.PARAMETER MGID
Mandatory. Management Group ID

.PARAMETER Stage
Mandatory. Landing Zone Stage

.EXAMPLE
Get-TargetMG -MGID "mg-corp" -stage "dev"

Returns "mg-dev-corp"
#>

function Get-TargetMG {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string] $MGID,

        [Parameter(Mandatory = $true)]
        [string] $stage
    )

    if (-not ($MGID -eq "mg-sap")) {
        If ($stage -eq "dev") {
            $outputMGID = "dev-"+$MGID
        }
        elseif ($stage -eq "build") {
            $outputMGID = "build-"+$MGID
        }
        else { 
            $outputMGID = $MGID
        }
    }
    else {
        $outputMGID = $MGID
    }
    
    return $outputMGID
}


