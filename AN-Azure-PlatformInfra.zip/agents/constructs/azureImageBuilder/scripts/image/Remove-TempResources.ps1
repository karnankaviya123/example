<#
.SYNOPSIS
Remove resources from RG

.DESCRIPTION
Remove resources from specified RG

.PARAMETER resourcegroupName
Required. The resource group name

.PARAMETER imageTemplateName
Optional. The name of the image template. Defaults to '*'.

.PARAMETER Confirm
Request the user to confirm whether to actually execute any should process

.PARAMETER WhatIf
Perform a dry run of the script. Runs everything but the content of any should process

.EXAMPLE
Remove-TempResources -resourcegroupName 'My-RG'

Search and remove the resources in 'My-RG'

#>
function Remove-TempResources {

    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName
    )

    begin {
        Write-Debug ('{0} entered' -f $MyInvocation.MyCommand)

        # Install required modules
        $currentVerbosePreference = $VerbosePreference
        $VerbosePreference = 'SilentlyContinue'
        $requiredModules = @(
            'Az.Resources',
            'Az.ResourceGraph'
        )
        foreach ($moduleName in $requiredModules) {
            if (-not ($installedModule = Get-Module $moduleName -ListAvailable)) {
                Install-Module $moduleName -Repository 'PSGallery' -Force -Scope 'CurrentUser'
                if ($installed = Get-Module -Name $moduleName -ListAvailable) {
                    Write-Verbose ('Installed module [{0}] with version [{1}]' -f $installed.Name, $installed.Version) -Verbose
                }
            } else {
                Write-Verbose ('Module [{0}] already installed in version [{1}]' -f $installedModule[0].Name, $installedModule[0].Version) -Verbose
            }
        }
        $VerbosePreference = $currentVerbosePreference
    }

    process {
        # Remove VMs first to delete resource dependencies
        [array]$tempVMs = (Search-AzGraph -Query "Resources | where resourceGroup == '$resourceGroupName' | where type == 'microsoft.compute/virtualmachines'")
        Write-Verbose ('Found [{0}] VMs to remove.' -f $tempVMs.Count)
        foreach ($tempVM in $tempVMs) {
            if ($PSCmdlet.ShouldProcess('VM [{0}]' -f $tempVM.Name, 'Remove-AzVM')) {
                $null = Remove-AzVM -Id $tempVM.id -Force
                Write-Verbose ('Removed VM [{0}]' -f $tempVM.id) -Verbose
            }
        }
        
        # List remaining resources (disks / interfaces)
        [array] $tempResources = (Search-AzGraph -Query "Resources | where resourceGroup == '$resourceGroupName'")
        Write-Verbose ('Found [{0}] resources to remove.' -f $tempResources.Count)

        foreach ($tempResource in $tempResources) {
            if ($PSCmdlet.ShouldProcess('Resource [{0}]' -f $tempResource.Name, 'Remove')) {
                $null = Remove-AzResource -ResourceId $tempResource.id -Force
                Write-Verbose ('Removed resource [{0}]' -f $tempResource.id) -Verbose
            }
        }
    }

    end {
        Write-Debug ('{0} exited' -f $MyInvocation.MyCommand)
    }

}