$PSDefaultParameterValues['*:Encoding'] = 'utf8'
Write-Host  "##[group]Start ARM TTK Pester Tests"

#Convert bicep files
$bicepCandidates = Get-ChildItem -Recurse -File -Include '*.bicep'
foreach ($bicepfile in $bicepCandidates) {
    bicep build $bicepfile
}

#Get Files contatining Azure schema and Resources -> This should sort out parameters
$JsonCandidates = Get-ChildItem -Recurse -File -Include '*.json' | Select-String "https://schema.management.azure.com/schemas/" | Select-Object Path | Sort-Object -Property path -Unique | Get-Item
$FilesToTest = @()
foreach ($JsonCandidate in $JsonCandidates) {
    if ($null -ne ($JsonCandidate | Get-Content | ConvertFrom-Json).resources) {
        $FilesToTest += $JsonCandidate 
    } 
}



# Only run if there are ARM Templates
if ($FilesToTest.count -gt 0) {

    #Download, Extract and Import ARM-TTK
    if ($ENV:AGENT_TEMPDIRECTORY) {
        #We are running in a AzDO Agent
        $SCRIPT:Tempfolder = $ENV:AGENT_TEMPDIRECTORY
    }
    else {
        # we are running localy
        $SCRIPT:Tempfolder = $ENV:TEMP
    }

    #Download Arm ttk if needed
    if (!$(Get-Module -Name arm-ttk)) {
        if (!$(Test-Path -path "$SCRIPT:Tempfolder/arm-template-toolkit" -PathType Container)) {
            Write-host "Downloading ARM TTK"
            Invoke-WebRequest https://azurequickstartsservice.blob.core.windows.net/ttk/latest/arm-template-toolkit.zip -OutFile "$SCRIPT:Tempfolder/arm-template-toolkit.zip" 
            Expand-Archive -LiteralPath "$SCRIPT:Tempfolder/arm-template-toolkit.zip" -DestinationPath "$SCRIPT:Tempfolder/arm-template-toolkit" 
        }
        Write-host "Importing ARM TTK"
        Import-Module "$SCRIPT:Tempfolder/arm-template-toolkit/arm-ttk/arm-ttk.psd1"
        #Update ttk cache (Api Versions...)
        Invoke-WebRequest -Method Get -Uri https://github.com/Azure/arm-ttk/raw/master/arm-ttk/cache/AllAzureResources.cache.json -OutFile "$((Get-Module -Name arm-ttk).ModuleBase)\cache\AllAzureResources.cache.json"
    }


    Write-host "Test $($FilesToTest.count) Files"

    # Actuall Tests
    $testresult = $FilesToTest | Test-AzTemplate -ErrorAction Continue -skip @(
        'Location Should Not Be Hardcoded', 
        'apiVersions Should Be Recent In Reference Functions',
        'Parameters Must Be Referenced',
        'Variables Must Be Referenced'
    )
    #Put the results into Pester
    $testedFiles = $testresult.file.FullPath | Sort-Object -Unique
    $testedFiles | ForEach-Object {
        $thisfile = $_
        Describe "$thisfile".Replace("$((Get-Location).path)", "") {
            #Iterate through groups and set it as context
            ($testresult | Where-Object { $_.file.FullPath -eq $thisfile }).group | Sort-Object -Unique | ForEach-Object {
                $thiscontext = $_
                Context $thiscontext {
                    $testresult | Where-Object { $_.file.FullPath -eq $thisfile -AND $_.group -eq $thiscontext } | ForEach-Object {

                        It "<name>" -TestCases @{name = $_.name; passed = $_.passed; Errors = $_.Errors } {
                            param($passed, $Errors)
                            $Errors | Should -BeNullOrEmpty
                            $passed | Should -be $true
                    
                        }
                    }
                } 
            }
        }
    }
}
else {
    Describe "ARMTTK" {
        Context "Test" {
            It 'No ARM Template Files to Test' {
                $true | Should -BeTrue
            }
        }
    }
}
Write-Host  "##[endgroup]"