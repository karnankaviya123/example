[CmdletBinding()]
param (
    [parameter(mandatory = $true)]
    [string] $subscriptionId,
    [parameter(mandatory = $true)]
    [string] $subscriptionName
)

function Confirm-SubscriptionName {
    <#
    .SYNOPSIS
    Check if subscription Name and ID belongs to the same subscription

    .DESCRIPTION
    Check if ID of provided subscription name is the same as provided subscription ID

    .PARAMETER subscriptionId
    Required. Id of Subscription.

    .PARAMETER subscriptionName
    Required. Name of Subscription.

    .EXAMPLE
    Confirm-SubscriptionName -subscriptionName "sub-xxx-xxx" subscriptionId "xxxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"

    #>
    [CmdletBinding()]
    param (
        [parameter(mandatory = $true)]
        [string] $subscriptionId,
        [parameter(mandatory = $true)]
        [string] $subscriptionName
    )
    Write-Verbose ("Searching for subscription {0} with Id {1}" -f $subscriptionName, $subscriptionId) -Verbose
    $subscriptionDetails = Get-AzSubscription -SubscriptionName $subscriptionName
    $ResourceGraphQuery = "resourcecontainers
    | where type == 'microsoft.resources/subscriptions'
    | where subscriptionId == '{0}'
    | project name, subscriptionId, ParentManagementGroup = properties.managementGroupAncestorsChain[0].displayName" -f $subscriptionId

    $subInfo = Search-AzGraph -Query $ResourceGraphQuery

    if ($subInfo.ParentManagementGroup -eq 'mg-decommissioned' -or $subInfo.ParentManagementGroup -eq 'dev-mg-decommissioned') {
        # This condition is required to protect incorrect subscription from being modified by next scripts
        # If not, script will throw an error
        Write-Verbose ("The subscription is inside of the {0} Managment Group" -f $subInfo.ParentManagementGroup) -Verbose

        if ($subscriptionDetails.Id -eq $subscriptionId) {
            Write-Verbose ("Found subscription {0} with Id {1}" -f $subscriptionName, $subscriptionId) -Verbose
        }
        else {
            Write-Verbose ("Subscription {0} with Id {1} not found" -f $subscriptionName, $subscriptionId) -Verbose
            throw "Incorrect subscription Name or Id"
        }
    }
    else {
       Write-Host "The subscription is not inside of the mg-decommissioned nor dev-mg-decommissioned Managment Group"
       throw "Incorrect Managment Group (subscription is not in mg-decommissioned/dev-mg-decommissioned)"
    }
    



}

Confirm-SubscriptionName -subscriptionName $subscriptionName -subscriptionId $subscriptionId