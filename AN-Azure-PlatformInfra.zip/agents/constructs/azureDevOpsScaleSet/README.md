# Azure DevOps Scale Set

This construct consists of several components in different places. You can use the following table to make sure you are aware of all the ones you need:

- Construct Templates, Scripts & Parameters: Folder `constructs\azureDevOpsScaleSet`
- Azure DevOps Pipelines: Folder  `.azuredevops\azureDevOpsScaleSet`
- [CARML](https://aka.ms/CARML) modules - these  aren't in a folder of their own, the CARML modules are held in a container regsitry within the Azure environment, which is referred in code

For further information, please refer to the Wiki for information on how to apply the construct.