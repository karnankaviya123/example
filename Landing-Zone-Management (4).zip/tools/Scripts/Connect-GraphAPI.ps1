<#
.SYNOPSIS
Connects to MS Graph using service principal's credentials

.DESCRIPTION
Requests access token for current service perincipal using clientId/secret flow. 
Connects to MS Graph using provided token. It usually valids for 1 hour only.
To grant access to service principal credentials via environment variables 2 methods can be used

# - task: AzureCLI@2
#   inputs:
#     azureSubscription: subscriptionName
#     addSpnToEnvironment: true

# - task: AzurePowerShell@5
#   inputs:
#     azureSubscription: subscriptionName
          
.EXAMPLE
Connect-GraphAPI

Creates MSGraph context. Can be checked by running Get-MgContext command
#>

function Connect-GraphAPI {
    [CmdletBinding()]
    param()

    # Import-Module Microsoft.Graph.DirectoryObjects -ErrorAction Stop
    # Import-Module Microsoft.Graph.Groups -ErrorAction Stop
    # Import-Module Microsoft.Graph.Users -ErrorAction Stop
    # Import-Module -Name Az -ErrorAction Stop

    Write-Verbose "Connecting to Graph" -Verbose
    
    $connection = Get-AzAccessToken -ResourceTypeName MSGraph

    # $connection | Format-List

    $token = $connection.Token
    $token = ConvertTo-SecureString -String $token -AsPlainText -Force

    # Write-Host "Exporting token: $token"
    # Write-Host ("##vso[task.setVariable variable=graph_token;]$token")
            
    # Write-Host "Connecting with token: $token"
    Connect-MgGraph -AccessToken $token
}