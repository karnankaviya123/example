

function Get-SecurityGroupNameTemplate {
    <#
    .SYNOPSIS
    Generate security group name template

    .DESCRIPTION
    Generate security group name template from input parameters

    .PARAMETER project
    Required. Project name of Subscription.

    .PARAMETER stage
    Required. Stage of Subscription.

    .PARAMETER context
    Optional. Subscription context.

    .PARAMETER number
    Optional. Subscription number.

    .EXAMPLE
    Get-SecurityGroupNameTemplate -project "ccoe" -stage "dev" -context "vmss" -number "001"

    #>
    [CmdletBinding()]
    param (
        [parameter(mandatory = $true)]
        [string] $project,
        [parameter(mandatory = $true)]
        [string] $stage,
        [parameter(mandatory = $false)]
        [string] $context,
        [parameter(mandatory = $false)]
        [string] $number
    )

$securityGroupNameTemplate = "AZR.WW.MST."+$project+".sub."+$stage

# Add Context and Number values to group name template (if provided).
# Value "<none>" is the default empty value in LZ create pipeline. 
# If it is provided as context or/and number the value shoudn't be added to group name.

if (($context -ne '<none>') -and (-not [String]::IsNullOrEmpty($context))) {
    $securityGroupNameTemplate = $securityGroupNameTemplate+"."+$context
}


if (($number -ne '<none>') -and (-not [String]::IsNullOrEmpty($number))) {
    $number = $number.PadLeft(3,'0')
    $securityGroupNameTemplate = $securityGroupNameTemplate+"."+$number
}

# Add parameter placeholder for role name
$securityGroupNameTemplate = $securityGroupNameTemplate+".{0}"

return $securityGroupNameTemplate

}