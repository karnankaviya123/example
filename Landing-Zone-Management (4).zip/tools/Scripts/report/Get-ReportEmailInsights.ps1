<#
.SYNOPSIS
Creates insights for report

.DESCRIPTION
Creates insights for report email body

.PARAMETER lzReportFile
Required. Landing zone report file name

.PARAMETER shaReportFile
Required. Self Hosted Agents report file name

.PARAMETER scReportFile
Required. Service connections report file

.EXAMPLE
Get-ReportEmailInsights-lzReportFile "lzreport.xlsx" -shaReportFile "shareport.xlsx" -scReportFile "screport.xlsx"

Function requires ImportExcel module

Returns report files
#>

function Get-ReportEmailInsights {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $lzReportFile,

        [Parameter(Mandatory = $true)]
        [string] $shaReportFile,

        [Parameter(Mandatory = $true)]
        [string] $scReportFile
    )

    # Variables
    $output = @{} 
    $noDataMessage = "Data unavailable"

    # Landing Zones
    if ((Test-Path -path $lzReportFile)) {
        # Collect statistics
        $requiredUpdateCount = (Import-Excel -Path $lzReportFile -WorksheetName "UpdateRequired" | Measure-Object).Count
        $updateAndMoveRequiredCount = (Import-Excel -Path $lzReportFile -WorksheetName "UpdateAndMoveRequired" | Measure-Object).Count
        $numberOfLzTotal = (Import-Excel -Path $lzReportFile -WorksheetName "allLZDetails"  | Measure-Object).Count
        $updatedLzCount = $numberOfLzTotal - $requiredUpdateCount - $updateAndMoveRequiredCount
        $requiredActionsCount = $requiredUpdateCount + $updateAndMoveRequiredCount

        # Add to output     
        $output.Add("updatedLzCount",$updatedLzCount)
        $output.Add("requiredActionsCount",$requiredActionsCount)
        $output.Add("numberOfLzTotal",$numberOfLzTotal)
    } 
    else {
        Write-Verbose ("Path [{0}] not found" -f $lzReportFile) -Verbose
        $output.Add("updatedLzCount",$noDataMessage)
        $output.Add("requiredActionsCount",$noDataMessage)
        $output.Add("numberOfLzTotal",$noDataMessage)
    }

    # Self Hosted Agents
    if ((Test-Path -path $shaReportFile)) {
        # Collect statistics
        $agentUsers = ((Import-Excel -Path $shaReportFile -WorksheetName "SelfHostedAgentPools").Project | Group-Object | Measure-Object).Count
        $numberOfAgentPools = (Import-Excel -Path $shaReportFile -WorksheetName "SelfHostedAgentPools" | Measure-Object).Count

        # Add to output   
        $output.Add("agentUsers",$agentUsers)
        $output.Add("numberOfAgentPools",$numberOfAgentPools)
    } 
    else {
        Write-Verbose ("Path [{0}] not found" -f $shaReportFile) -Verbose
        $output.Add("agentUsers",$noDataMessage)
        $output.Add("numberOfAgentPools",$noDataMessage)
    }

    # Service Connections
    if ((Test-Path -path $scReportFile)) {
        # Collect statistics
        $numberOfSecrets = (Import-Excel -Path $scReportFile -WorksheetName "ServiceConnections" | Measure-Object).Count
        $secretsExp60 = (Import-Excel -Path $scReportFile -WorksheetName "ServiceConnections" | Where-Object {($_.ExpiresInDays -lt 60) -and ($_.ExpiresInDays -gt 0)} | Measure-Object).Count
        $expiredSecrets = (Import-Excel -Path $scReportFile -WorksheetName "ServiceConnections" | Where-Object {$_.ExpiresInDays -lt 0} | Measure-Object).Count

        # Add to output   
        $output.Add("numberOfSecrets",$numberOfSecrets)
        $output.Add("secretsExp60",$secretsExp60)
        $output.Add("expiredSecrets",$expiredSecrets)
    } 
    else {
        Write-Verbose ("Path [{0}] not found" -f $scReportFile) -Verbose
        $output.Add("numberOfSecrets",$noDataMessage)
        $output.Add("secretsExp60",$noDataMessage)
        $output.Add("expiredSecrets",$noDataMessage)
    }

    return $output
}


