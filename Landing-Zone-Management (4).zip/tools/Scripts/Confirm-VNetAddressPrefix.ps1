<#
.SYNOPSIS
Check the provided list of address prefixes regarding their structure and availability

.DESCRIPTION
Check the provided list of address prefixes regarding their structure and availability

.PARAMETER addressPrefixes
Mandatory. The address prefixes to check

.PARAMETER vnetRGName
Mandatory. The name of the rg of the VNET to be created

.PARAMETER vnetName
Mandatory. The name of the VNET to be created

.EXAMPLE
Confirm-VNETAddressPrefix -AddressPrefixes @('192.167.153.1/24')
#>
function Confirm-VNetAddressPrefix {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string[]] $addressPrefixes,

        [Parameter(Mandatory = $false)]
        [string] $vnetRGName,

        [Parameter(Mandatory = $false)]
        [string] $vnetName,

        [Parameter(Mandatory = $false)]
        [string] $existingSubscriptionId
    )

    # Warning: Only works with subscriptions the principal has READ access to

    $foundErrors = 0
    # List of excluded VNETs which do not follow "Cloud dedicated" network range 10.227.0.0/16 - 10.228.0.0/17.
    $excludedVNETNames = [System.Collections.ArrayList]@("vnet-acd-inf-csadm","soc_prd_test-vnet")

    $vNetGraphQuery = 'resources
    | where type == "microsoft.network/virtualnetworks"
    | project name, id, properties.addressSpace.addressPrefixes'
    $existingVNETs = Search-AzGraph -Query $vNetGraphQuery -First 1000

    # Generate VNet resource ID from runtime parameters
    $generatedVNetResourceId = ('/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Network/virtualNetworks/{2}' -f $existingSubscriptionId, $VnetRGName, $vnetName)
    
    ## Validate
    # Address space
    foreach ($addressPrefix in $AddressPrefixes) {

        # Check format
        if ($addressPrefix -notmatch '^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/[0-9]{1,2}$') {
            Write-Error ('Address space [{0}] of virtual network [{1}] is not valid' -f $addressPrefix, $vnetName) -ErrorAction 'Continue'
            $foundErrors++
        }
        
        # Check if IP range can be used in Azure infrastructure
        # Due to non-standard IP ranges in existing Landing Zones exceptions have been added.
        # Exceptions are not affecting new Landing Zones - only existing ones.
        If ($excludedVNETNames -contains $vnetName) {
            Write-Verbose "Skipping IP address range verification [$vnetRGName|$vnetName] of subscription [$existingSubscriptionId] as it was found in exclusions list." -Verbose
        }
        elseif ($addressPrefix.Split("/")[0] -notmatch '^10\.(227\.0\.([1-9]|[1-9]\d|[12]\d\d)|227\.([1-9]|[1-9]\d|[12]\d\d)\.([1-9]?\d|[12]\d\d)|228\.127\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-4])|228\.([1-9]?\d|1[01]\d|12[0-6])\.([1-9]?\d|[12]\d\d))$') {
            Write-Error ('Address space [{0}] of virtual network [{1}] cannot be used in Azure infrastructure' -f $addressPrefix, $vnetName) -ErrorAction 'Continue'
            $foundErrors++
        }

        # Check if already used - Overlaps are ignored for now
        if ((-not [String]::IsNullOrEmpty($existingSubscriptionId)) -and $existingVNETs.id -contains $generatedVNetResourceId) {
            # Check if existing VNet address space is used in any other VNet.
            foreach ($existingVNET in $existingVNETs) {
                if (($existingVNET.properties_AddressSpace_AddressPrefixes -contains $addressPrefix) -and ($existingVNET.name -ne $vnetName)) {
                    Write-Error ('Address space [{0}] for virtual network [{1}|{2}] is already used by virtual network [{3}]' -f $addressPrefix, $vnetRGName, $vnetName, $existingVNET.Id) -ErrorAction 'Continue'
                    $foundErrors++
                }
            }
        }
        else {
            # Only check if address space is used in other VNets
            foreach ($existingVNET in $existingVNETs) {
                if ($existingVNET.properties_AddressSpace_AddressPrefixes -contains $addressPrefix) {
                    Write-Error ('Address space [{0}] for virtual network [{1}|{2}] is already used by virtual network [{3}]' -f $addressPrefix, $vnetRGName, $vnetName, $existingVNET.Id) -ErrorAction 'Continue'
                    $foundErrors++
                }
            }     
        }
    }

    if ($foundErrors -gt 0) {
        throw "Found [{$foundErrors}] issues with the configured virtual networks. Please examine raised errors."
    }

    Write-Verbose "Address prefix [$addressPrefix] is valid" -Verbose
}

