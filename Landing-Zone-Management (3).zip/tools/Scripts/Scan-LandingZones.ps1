# This script is designed to generate Landing Zone config files (lzconfig.json)
# from existing subscriptions deployed in the Management Groups mg-corp and mg-online.

# For all subscriptions, which are not comppatible with the current LZ definition and the lzconfig.json
# cannot be created, a simple resource stats are being generated and stored in a CSV file. This
# should help to categorize the non-compatible subscriptions.

# As this script has been written for a one-time execution, it's not fully parametrized and documented. 
# Please modify the paths to your needs before launching it.

$outputRootFolder = "C:\Local\Repos\AldiN\Landing-Zone-Management\LZConfig"
$scriptsFolder = "C:\Local\Repos\AldiN\Landing-Zone-Management\tools\Scripts"


<#
.SYNOPSIS
Scans all subscriptions in a given Management Group and generates the LZ config file (lzconfig.json)

.DESCRIPTION
The function tries to generate the lzconfig.json file from all subscriptions in a given Management Group.

.PARAMETER ManagementGroupId
Required. Id of a Management Group to scan

.EXAMPLE
Scan-LandingZones
#>
function Scan-LandingZones {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $ManagementGroupId
    )

    # searching for all subscription in the given Management Group and 
    # running the function Get-LandingZoneConfig for each of them.
    # Storing a subscription info file (csv) AND generating an LZConfig file 
    # (lzconfig.json) if all criteria are fullfiled.

    $ResourceGraphQuery = "resourcecontainers
    | where type == 'microsoft.resources/subscriptions'
    | where properties.managementGroupAncestorsChain[0].displayName == '{0}'
    | project ParentManagementGroup = properties.managementGroupAncestorsChain[0].displayName, name, subscriptionId" -f $ManagementGroupId
    $subCollection = Search-AzGraph -Query $ResourceGraphQuery

    $subscriptionsInfo = @()
    foreach ($Subscription in $subCollection) {
        try {
            $subscriptionsInfo += Get-LandingZoneConfig -SubscriptionId $Subscription.subscriptionId
            Write-Verbose ("Processing subscription [{0}, id {1}] succeeded..." -f $Subscription.name, $Subscription.subscriptionId) -Verbose
        }
        catch {
            Write-Verbose ("Processing subscription [{0}, id {1}] failed..." -f $Subscription.name, $Subscription.subscriptionId) -Verbose
        }
    }

    $subscriptionsInfo | Export-Csv -Path "C:\Local\Repos\AldiN\Landing-Zone-Management\subscriptionsInfo-$ManagementGroupId.csv" -Force
    return 0
}

function Install-Modules {
    $requiredModules = @(
        #'Az.Resources',
        #'Az.Subscription',
        # 'Az.Accounts',
        #'Az.Network',
        'Az.ResourceGraph'
    )          
    foreach ($module in $requiredModules) {
        if (-not (Get-Module $module -ListAvailable)) {
            Install-Module $module -Scope CurrentUser -Force
            Write-Verbose ("Module [$module] was installed") -Verbose
        }
        else {
            Write-Verbose ("Module [$module] is already installed") -Verbose
        }
    }
}


<#
.SYNOPSIS
Reads subscription's resources and generates the Landing Zone config file (lzconfig.json)

.DESCRIPTION
The function tries to generate the lzconfig.json file describing the Landing Zone config
of a given subscription. The properties of the output JSON file are ordered alphabetically

.PARAMETER SubscriptionId
Required. Id of a Subscription to scan

.EXAMPLE
Get-LandingZoneConfig
#>
function Get-LandingZoneConfig {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $SubscriptionId
    )

    # Subscription verification
    $sub = Get-AzSubscription -SubscriptionId $SubscriptionId
    if (!$sub) {
        throw ("Subscription with the id [{0}] not found" -f $SubscriptionId)
    }
    Write-Verbose ("Processing subscription [{0}], Id [{1}]..." -f $sub.Name, $SubscriptionId)

    # initializing output objects: $lzinfo for the csv export, $lzconfig for the json output
    $lzinfo = [pscustomobject][ordered] @{}
    $lzconfig = [pscustomobject][ordered] @{}
    $lzconfigerror = $false

    # adding subscription info to the result object
    $lzinfo | Add-Member -MemberType NoteProperty -Name 'SubscriptionName' -Value $sub.Name
    $lzinfo | Add-Member -MemberType NoteProperty -Name 'SubscriptionId' -Value $SubscriptionId

    # Query for parent Management Group and Tags
    $ResourceGraphQuery = "resourcecontainers
    | where type == 'microsoft.resources/subscriptions'
    | where subscriptionId == '{0}'
    | project name, subscriptionId, tags, properties" -f $SubscriptionId
    $subInfo = Search-AzGraph -Query $ResourceGraphQuery

    # adding management group info to the result object
    $lzinfo | Add-Member -MemberType NoteProperty -Name 'ManagementGroup' -Value $subInfo.properties.managementGroupAncestorsChain[0].name

    # Determine ProjectName and Stage based on subscription Name
    # 3 name parts are corrct, but we are accepting also and 7 parts
    $nameSplit = $sub.name.Split("-")
    $lzinfo | Add-Member -MemberType NoteProperty -Name 'NameParts' -Value $nameSplit.Count

    if ($nameSplit.Count -eq 3 -or $nameSplit.Count -eq 7) {
        $ProjectName = $nameSplit[$nameSplit.Count - 2]
        $Stage = $nameSplit[$nameSplit.Count - 1]
    }
    else {
        $lzconfigerror = $true
    }

    # Query for VNets
    $ResourceGraphQuery = "resources
    | where type == 'microsoft.network/virtualnetworks'
    | where subscriptionId == '{0}'
    | project name, resourceGroup, properties" -f $SubscriptionId, $vnetRGName, $vnetName

    $vnetInfo1 = Search-AzGraph -Query $ResourceGraphQuery
    $lzinfo | Add-Member -MemberType NoteProperty -Name 'VNetsCount' -Value $vnetInfo1.Count

    $peeredVnets = 0
    $selectedVnet = @{}

    if ($vnetInfo1.Count -eq 0) {
        $lzconfigerror = $true # no vnets = LZ Config error
    }
    else {
        
        foreach ($vnet in $vnetInfo1) {
            # for mg-corp we are looking for a peered vnet
            if ($vnet.Properties.virtualNetworkPeerings) {
                $peeredVnets++
                $selectedVnet = $vnet
            }
            # for mg-online we selecting any vnet 
            if ($subInfo.properties.managementGroupAncestorsChain[0].name -eq "mg-online") {
                $selectedVnet = $vnet
            }
        }

        if ($peeredVnets -gt 1) { $lzconfigerror = $true }
        
        if ($peeredVnets -eq 0) { 
            if ($subInfo.properties.managementGroupAncestorsChain[0].name -eq "mg-corp") {
                $lzconfigerror = $true 
            }
        }
    }
    $lzinfo | Add-Member -MemberType NoteProperty -Name 'PeeredVNets' -Value $peeredVnets


    # Query for Recovery Services Vaults
    $ResourceGraphQuery = "resources
    | where type == 'microsoft.recoveryservices/vaults'
    | where subscriptionId == '{0}'
    | project name, resourceGroup, location, properties" -f $SubscriptionId

    $rsvInfo = Search-AzGraph -Query $ResourceGraphQuery
    $lzinfo | Add-Member -MemberType NoteProperty -Name 'rsvCount' -Value $rsvInfo.Count

    if ($rsvInfo.Count -lt 2) { $lzconfigerror = $true }

    $rsvNEU = 0
    $rsvWEU = 0
    foreach ($rsv in $rsvInfo) {
        if ($rsv.location -eq "northeurope") { 
            $rsvNEU++
            $rsvNEUName     = $rsv.name
            $rsvNEURG       = $rsv.resourceGroup
        }
        if ($rsv.location -eq "westeurope")  {
            $rsvWEU++
            $rsvWEUName     = $rsv.name
            $rsvWEURG       = $rsv.resourceGroup
        }
    }

    if ($rsvNEU -eq 0) { $lzconfigerror = $true }
    if ($rsvWEU -eq 0) { $lzconfigerror = $true }

    $ResourceGraphQuery = "policyresources
    | where type == 'microsoft.authorization/policyassignments'
    | where properties.scope == '/subscriptions/{0}'
    | where properties.policyDefinitionId == '/providers/Microsoft.Authorization/policyDefinitions/09ce66bc-1220-4153-8104-e3f51c936913'" -f $SubscriptionId

    $policyInfo = Search-AzGraph -Query $ResourceGraphQuery
    $lzinfo | Add-Member -MemberType NoteProperty -Name 'backupPolicies' -Value $policyInfo.Count

    if ($policyInfo.Count -lt 2) { $lzconfigerror = $true }

    if (!$lzconfigerror) {
        $lzinfo | Add-Member -MemberType NoteProperty -Name 'lzConfig' -Value 1

        # Prepare output paths
        $outputFolder = Join-Path $outputRootFolder $subInfo.properties.managementGroupAncestorsChain[0].name $sub.Name
        if (!(Test-Path -path $outputFolder)) { New-Item $outputFolder -Type Directory -Force }
        $destinationPath = Join-Path $outputFolder 'lzconfig.json'

        # putting all together, creating a result object
        if($selectedVnet.Properties.dhcpOptions.dnsServers) {
            $dnsServers = $selectedVnet.Properties.dhcpOptions.dnsServers
        }
        else {
            $dnsServers = @()
        }

        $resPathsObj = [pscustomobject][ordered] @{}
        $resPathsObj | Add-Member -MemberType NoteProperty -Name 'rgVnet' -Value $selectedVnet.resourceGroup
        $resPathsObj | Add-Member -MemberType NoteProperty -Name 'vnetName' -Value $selectedVnet.name
        $resPathsObj | Add-Member -MemberType NoteProperty -Name 'rgRsvNorthEurope' -Value $rsvNEURG
        $resPathsObj | Add-Member -MemberType NoteProperty -Name 'rgRsvWestEurope' -Value $rsvWEURG
        $resPathsObj | Add-Member -MemberType NoteProperty -Name 'rsvNameNorthEurope' -Value $rsvNEUName
        $resPathsObj | Add-Member -MemberType NoteProperty -Name 'rsvNameWestEurope' -Value $rsvWEUName

        $lzconfig | Add-Member -MemberType NoteProperty -Name 'MgmtGrId' -Value $subInfo.properties.managementGroupAncestorsChain[0].name
        $lzconfig | Add-Member -MemberType NoteProperty -Name 'ProjectName' -Value $ProjectName
        $lzconfig | Add-Member -MemberType NoteProperty -Name 'Stage' -Value $Stage
        $lzconfig | Add-Member -MemberType NoteProperty -Name 'Tag' -Value $subInfo.tags
        $lzconfig | Add-Member -MemberType NoteProperty -Name 'vnetAddressPrefix' -Value $selectedVnet.Properties.addressSpace.addressPrefixes[0]
        $lzconfig | Add-Member -MemberType NoteProperty -Name 'vnetDNSServers' -Value $dnsServers
        $lzconfig | Add-Member -MemberType NoteProperty -Name 'ResourceNames' -Value $resPathsObj
        $lzconfig | ConvertTo-Json -Depth 99 |  Out-File -FilePath $destinationPath

        # Sorting the properties of the json file alphabetically to ensure the same oder on each run 
        # Loading sorting functions 
        . (Join-Path $scriptsFolder 'Get-SortedJsonFile.ps1')
        # Sorting JSON file properties 
        Get-SortedJsonFile -jsonFilePath $destinationPath
        
    }
    else {
        $lzinfo | Add-Member -MemberType NoteProperty -Name 'lzConfig' -Value 0
    }

    return $lzinfo
}
# Get-LandingZoneConfig -SubscriptionId "d8dd40a1-2b70-4660-bb52-53254a86d8ee"
Scan-LandingZones -ManagementGroupId 'mg-online'
Scan-LandingZones -ManagementGroupId 'mg-corp'