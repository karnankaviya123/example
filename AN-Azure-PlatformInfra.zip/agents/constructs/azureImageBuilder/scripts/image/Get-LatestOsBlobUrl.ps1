<#
.SYNOPSIS
Retrieves the latest blob from the provided parameters of a particular OS.

.DESCRIPTION
All blobs will be listed in an object and as the blob has only one VHD, the blob list will be filtered for only VHD files and the selected OS.
As a result, the name of the blob container is returned to build the blob url.

.PARAMETER osType
Mandatory. The type of Operating System (either Windows or Linux)

.PARAMETER storageContainerName
Mandatory. The Storage Account Container containing the blobs

.PARAMETER storageAccountName
Mandatory. The Storage Account containing the blobs

.EXAMPLE
$blobs = @(
    'Microsoft.Compute/Images/images/agent-lin-osDisk.a24b6e93-80ae-49eb-beea-1769349e7262.vhd',
    'Microsoft.Compute/Images/images/agent-lin-vmTemplate.f4b9r0wq-8720-4r8t-8d94-7u5j7h180a09.json'
    'Microsoft.Compute/Images/images/agent-win-osDisk.e4a9c0ac-8720-408e-8b94-7e5c7d180c09.vhd',
    'Microsoft.Compute/Images/images/agent-win-vmTemplate.e4a9c0ac-8720-408e-8b94-7e5c7d180c09.json'
)
Get-LatestOSBlobUrl -osType 'Linux' -ImageStorageAccountContainerName 'system' -ImageStorageAccountName 'myStorageAccount'

Will select the the following object:

    'Microsoft.Compute/Images/images/agent-lin-osDisk.a24b6e93-80ae-49eb-beea-1769349e7262.vhd'

This is because it is a VHD and is of Linux 'osType'.

Then the string name of the object will be returned
#>

function Get-LatestOsBlobUrl {

    [CmdletBinding()]
    [OutputType('String')]
    param (
        [Parameter(Mandatory)]
        [string] $osType,

        [Parameter(Mandatory)]
        [string] $storageContainerName,

        [Parameter(Mandatory)]
        [string] $storageAccountName
    )

    # Choose the file prefix for the filering of the latest blob
    if ($osType -eq 'Windows') {
        $filePrefix = "Microsoft.Compute/Images/images/agent-win*"
    }
    else {
        $filePrefix = "Microsoft.Compute/Images/images/agent-lin*"
    }

    # Gather the context for the blob container
    $ctx = New-AzStorageContext -StorageAccountName $storageAccountName -UseConnectedAccount
    
    # Select all the blob VHDs in the container 
    $vhdBlobs = Get-AzStorageBlob -Container $storageContainerName -Context $ctx | Where-Object { (Split-Path $_.name -Extension) -eq '.vhd' } | Select name

    if (-not $vhdBlobs) {
        throw "No VHD blobs found in container [$storageAccountName/$storageContainerName]"
    }

    # Choose the VHD with the correct OS.
    $selectedObject = $vhdBlobs | Where-Object { $_.name -like $filePrefix } | Select name

    if (-not $selectedObject) {
        throw "No VHD blob for this OS Type found in container [$storageAccountName/$storageContainerName]"
    }

    return $selectedObject.name
}