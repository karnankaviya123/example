# Function to make REST API calls using Azure CLI 'az rest'
function Invoke-RESTCommand {
    [CmdletBinding()]
    <# 
        Parameters:
            - method: HTTP method (GET, POST, etc.)
            - uri: URI for the REST API endpoint
            - body: Request body for POST requests
            - header: Headers for the request
        Returns: Parsed JSON response or raw response if not JSON
    #>

    param (
        [Parameter(Mandatory = $true)]
        [string] $method,
        [Parameter(Mandatory = $true)]
        [string] $uri,
        [Parameter(Mandatory = $false)]
        [string] $body,
        [Parameter(Mandatory = $false)]
        [hashtable] $header
    )
    try {
        $inputObject = @(
            '--method', $method,
            '--uri', $uri
        )
        # Build Body
        # ---------
        if ($body) {
            $tmpPath = Join-Path $PSScriptRoot ("REST-$method-{0}.json" -f (New-Guid))
            $body | Out-File -FilePath $tmpPath -Force
            $inputObject += '--body', "@$tmpPath"
        }
        # Build Header
        # -----------
        
        if (-not $header) {
            $header = @{}
        }

        $compressedHeader = ConvertTo-Json $header -Depth 10 -Compress

        if ($compressedHeader.length -gt 2) {
            # non-empty
            $tmpPathHeader = Join-Path $PSScriptRoot ("REST-$method-header-{0}.json" -f (New-Guid))
            $compressedHeader | Out-File -FilePath $tmpPathHeader -Force
            $inputObject += '--headers', "@$tmpPathHeader"
        }
        # Execute
        # -------
        try {
            $rawResponse = az rest @inputObject -o json 2>&1
            #Write-Verbose  "REST response: $rawResponse" -Verbose
        }
        catch {
            $rawResponse = $_
            #Write-Verbose  "REST error: $rawResponse" -Verbose
        }
        if ($rawResponse.Exception) {
            $rawResponse = $rawResponse.Exception.Message
        }
        # Remove wrappers such as 'Conflict({...})' from the repsonse
        if (($rawResponse -is [string]) -and $rawResponse -match '^[a-zA-Z].+?\((.*)\)$') {
            if ($Matches.count -gt 0) {
                $rawResponse = $Matches[1]
            }
        }
        if ($rawResponse) {
            if (Test-Json ($rawResponse | Out-String) -ErrorAction 'SilentlyContinue') {
                return (($rawResponse | Out-String) | ConvertFrom-Json)
            }
            else {
                return $rawResponse
            }
        }
    }
    catch {
        throw $_
    }
    finally {
        # Remove temp files
        if ((-not [String]::IsNullOrEmpty($tmpPathHeader)) -and (Test-Path $tmpPathHeader)) {
            Remove-item -Path $tmpPathHeader -Force
        }
        if ((-not [String]::IsNullOrEmpty($tmpPath)) -and (Test-Path $tmpPath)) {
            Remove-item -Path $tmpPath -Force
        }
    }
}

# Function to retrieve group display name from Azure AD by ObjectId
function Get-GroupNameByObjectId {
    <# 
        Parameters:
            - objectId: Azure AD object ID of the group
        Returns: Group display name or $null if not found
    #>
    param (
        [string]$objectId
    )

    $uri = "https://graph.microsoft.com/v1.0/groups/$objectId"

    try {
        
        $group = Invoke-RESTCommand -Uri $uri -Method GET
        
        $groupName = $group.displayName

        if ($groupName -like "AZR.WW.MST*") {
            if ($groupName -match "(?:Contributor|Reader|Owner)$") {
                return $groupName
            } else {
                return $null
            }
        } else {
            return $null
        }
    } catch {
        return $null
    }
}

# Function to retrieve the subscription information and Azure role assignments for subscriptions that are present in corp , online and sap management groups. Also this fetches the notification group name of subscriptiions based on workload teams tag (ccoe_workloadteam)
function Get-RoleAssignmentsAndWorkloadTeams {
    <# 
        Uses:
            - Invoke-RESTCommand
            - Get-GroupNameByObjectId
            - SyncGroupMembers
            - Get-AllProjectsandSubscriptionNotificationGroupMembers
            - Add-MissingMembersToAllProjectsNotificationGroup
        Returns:
            - GroupNames: Array of group names
            - subscriptionNotificationGroups: Array of subscription notification groups
    #>

    $matchingSubscriptions = Search-AzGraph -Query "resourcecontainers | where type == 'microsoft.resources/subscriptions' | extend mgParent = tostring(properties.managementGroupAncestorsChain[0].name) | where mgParent contains 'corp' or mgParent contains 'online' or mgParent contains 'sap' | project DisplayName = mgParent, id, name, ccoe_workloadteam = tostring(tags.ccoe_workloadteam)"

    $GroupNames = @()

    $subscriptionNotificationGroups = @()

    foreach ($subscription in $matchingSubscriptions) {
        if ($subscription -match "DisplayName=(.*?);.*id=\/subscriptions\/(.*?);.*name=(.*?);.*ccoe_workloadteam=(.*?);") {
            $GroupSets = @()

            $subscriptionId = $matches[2]
            $subscriptionName = $matches[3]
            $subscriptionNotificationGroupfullDL = $matches[4]
            $subscriptionNotificationGroupDL = $subscriptionNotificationGroupfullDL -replace "@aldi-nord.com", ""

            $GroupSets += $subscriptionNotificationGroupDL
            $GroupNames += $subscriptionNotificationGroupDL
            $subscriptionNotificationGroups += $subscriptionNotificationGroupDL

            Set-AzContext -Subscription $subscriptionId

            $resturi = "https://management.azure.com/subscriptions/$subscriptionId/providers/Microsoft.Authorization/roleAssignments?api-version=2022-04-01"
            $roleAssignments = Invoke-RESTCommand -Uri $resturi -Method GET
            

            foreach ($assignment in $roleAssignments.value) {
                $groupNamesafterfiltering = @() 
                $objectId = $assignment.properties.principalId
                $principalType = $assignment.properties.principalType

                if ($principalType -eq "Group") {

                    $AADgroupName = Get-GroupNameByObjectId -objectId $objectId

                    if ($AADgroupName -ne $null) {
                        $groupNamesafterfiltering += $AADgroupName
                    }

                }

                if ($groupNamesafterfiltering.Count -gt 0) {
                    $GroupSets += $groupNamesafterfiltering
                    $GroupNames += $groupNamesafterfiltering
                }
            }
            
            Write-Host ($GroupSets -join ', ') -Verbose
            $Groups = ($GroupSets -join ', ')
            SyncGroupMembers -groupNames $Groups
        }
    }
    $subscriptionNotificationGroupsDLs = @()
    $subscriptionNotificationGroupsDLs += $($subscriptionNotificationGroups -join ', ')
    Write-Host ($subscriptionNotificationGroupsDLs) -Verbose
    $O365Name = ("AZR.AA.ALL.O365.allprojects.Notification")
    $O365Id = "f955d9f8-94d4-472e-9859-402b9d96a86a"
    $membersAllSubscriptionsNotificationgroups = Get-AllProjectsandSubscriptionNotificationGroupMembers -groupNames $subscriptionNotificationGroups
    
    $membersAllProjects = Get-AllProjectsandSubscriptionNotificationGroupMembers -groupNames $O365Name
    
    $missingItems = Compare-Object -ReferenceObject $membersAllSubscriptionsNotificationgroups -DifferenceObject $membersAllProjects | Where-Object { $_.SideIndicator -eq '<=' } | Select-Object -ExpandProperty InputObject

    if ($missingItems -ne $null) {
        $missingUserIdsAllProjects = $($missingItems -join ', ')
        Add-MissingMembersToAllProjectsNotificationGroup -groupId $O365Id -groupName $O365Name -userIds $missingItems
        Write-Host "Missing members in AllSubscriptionsNotificationgroups compared to $O365Name : $($missingItems -join ', ')" -Verbose
    }
    return $GroupNames , $subscriptionNotificationGroups
}


# Function to add (sync) group members that are present in subscription's contributor,owner and reader groups and not present in its respective notification groups
# This function is called in Get-RoleAssignmentsAndWorkloadTeams function
function SyncGroupMembers {
[CmdletBinding(SupportsShouldProcess = $true)]
    <# 
        Parameters:
            - groupNames: Array of group names to synchronize
    #>
param (
    [Parameter(Mandatory = $true,
        HelpMessage = "Group Names")]
    [string[]]$groupNames
)

# Helper function to get Azure AD group ID by display name
# This function is called in Get-GroupMembers function
function Get-GroupIdByDisplayName($displayName) {
    <# 
        Parameters:
            - displayName: Display name of the Azure AD group
        Uses:
            - Invoke-RESTCommand
        Returns: Azure AD group ID or $null if not found
    #>
    $graphApiUrl = "https://graph.microsoft.com/v1.0/groups"
    $query = "?`$filter=displayName eq '$displayName'"
    $graphApiUrlquery = "$graphApiUrl$query"
    $group = Invoke-RESTCommand -method 'GET' -uri $graphApiUrlquery
    if ($group.value.Count -gt 0) {
        return $group.value[0].id
    } else {
        return $null 
    }
}

# Helper function to get members with names and IDs of an Azure AD group
# This function is called in Get-GroupMembers function
function Get-GroupMembersWithNamesAndIDs($groupId) {
    <# 
        Parameters:
            - groupId: Azure AD group ID
        Uses:
            - Invoke-RESTCommand
        Returns: Hashtable of member display names and IDs
    #>
    $graphApiUrl = "https://graph.microsoft.com/v1.0/groups/$groupId/members"
    $members = Invoke-RESTCommand -method 'GET' -uri $graphApiUrl
    $memberHashtable = @{}
    foreach ($member in $members.value) {
        $memberHashtable[$member.displayName] = $member.id
    }
    return $memberHashtable
}

# Function to get members of specified group names
function Get-GroupMembers {
  <# 
      Parameters:
          - groupNames: Array of group names
      Uses:
          - Get-GroupIdByDisplayName
          - Get-GroupMembersWithNamesAndIDs
      Returns:
          - notificationMembers: Hashtable of notification group members
          - contributorOwnerReaderMembers: Hashtable of contributor, owner, reader group members
          - notificationgroupID: Azure AD group object ID of notification group
          - notificationgroupName: Display name of the notification group
  #>
  param (
     [string[]]$groupNames
  )
  $contributorOwnerReaderMembers = @{}
  $notificationMembers = @{}

  foreach ($groupName in $groupNames) {
    $groupID = Get-GroupIdByDisplayName -displayName $groupName
    $membersWithNamesAndIDs = Get-GroupMembersWithNamesAndIDs -groupId $groupID
    
    Write-Verbose "$groupName" -Verbose

    $groupMembers = [ordered]@{
        "GroupName" = $groupName
        "GroupID" = $groupID
        "MembersNames" = $membersWithNamesAndIDs.keys
        "MemberIds" = $membersWithNamesAndIDs.values
    }

    if ($groupName -imatch "O365") {
        $notificationgroupName = $groupName
        $notificationgroupID = $groupID
        foreach ($member in $membersWithNamesAndIDs.keys) {
            if ($member -imatch '\(.*\)') {
                $NotificationmemberNameWithoutParentheses = $member -replace '\(.*\)'
                $NotificationmemberNameWithoutParentheses = $NotificationmemberNameWithoutParentheses.Trim()
            } else {
                $NotificationmemberNameWithoutParentheses = $member
            }
            $notificationMembers[$NotificationmemberNameWithoutParentheses] = $membersWithNamesAndIDs[$member]
        }
    }
    if ($groupName -imatch "Contributor" -or $groupName -imatch "Owner" -or $groupName -imatch "Reader") {
        foreach ($member in $membersWithNamesAndIDs.keys) {
            if ($member -imatch '\(.*\)') {
                $memberNameWithoutParentheses = $member -replace '\(.*\)'
                $memberNameWithoutParentheses = $memberNameWithoutParentheses.Trim()
            } else {
                $memberNameWithoutParentheses = $member
            }
            $contributorOwnerReaderMembers[$memberNameWithoutParentheses] = $membersWithNamesAndIDs[$member]
        }
     }
    }
    return $notificationMembers, $contributorOwnerReaderMembers, $notificationgroupID, $notificationgroupName
}


# Function to get missing members and their IDs
function Get-MissingMembersAndIds {
    <# 
        Parameters:
            - contributorOwnerReaderMembers: Hashtable of contributor, owner, reader group members
            - notificationMembers: Hashtable of notification group members
        Uses:
            - Invoke-RESTCommand
        Returns:
            - missingMembers: Array of missing member display names
            - userIds: Array of missing member IDs
    #>

    param (
        $contributorOwnerReaderMembers,
        $notificationMembers
    )

    $missingMembers = $contributorOwnerReaderMembers.Keys | Where-Object {
        $_ -notin $notificationMembers.Keys
    }

    $userIds = @()

    foreach ($displayName in $missingMembers) {
        
        $combinations = @()

        if ($displayName -like '*,*'){
                   $displayName = $displayName -replace ',', ''
         }
        
        if ($displayName -match '(\S+)\s(\S+)') {
            $displayNameReversed = "$($Matches[2]) $($Matches[1])"
            $normalizedDisplayName = $displayName.ToLower() -replace '\s+', '.'
            $normalizedDisplayNameReversed = $displayNameReversed.ToLower() -replace '\s+', '.'
            $combinations += $normalizedDisplayName
            $combinations += $normalizedDisplayNameReversed
            if ($displayName -match '(\S+)\-(\S+)\s(\S+)') {
                $combinations += ($Matches[1] + "." + $Matches[3]).ToLower()
                $combinations += ($Matches[2] + "." + $Matches[3]).ToLower()
                $combinations += ($Matches[3] + "." + $Matches[1]).ToLower()
                $combinations += ($Matches[3] + "." + $Matches[2]).ToLower()
                $combinations += ($Matches[2] + "-" + $Matches[1] + "." + $Matches[3]).ToLower()
                $combinations += ($Matches[3] + "." + $Matches[2] + "-" + $Matches[1]).ToLower()
                $combinations += ($Matches[2][0] + "." + $displayName.Split(" ")[-1]).ToLower()
            }
            if ($displayName -match '(\S+)\s(\S+)\-(\S+)') {
                $combinations += ($Matches[1] + "." + $Matches[2]).ToLower()
                $combinations += ($Matches[1] + "." + $Matches[3]).ToLower()
                $combinations += ($Matches[2] + "." + $Matches[1]).ToLower()
                $combinations += ($Matches[3] + "." + $Matches[1]).ToLower()
                $combinations += ($Matches[3] + "-" + $Matches[2] + "." + $Matches[1]).ToLower()
                $combinations += ($Matches[1] + "." + $Matches[3] + "-" + $Matches[2] ).ToLower()
                $combinations += ($Matches[3][0] + "." + $displayNameReversed.Split(" ")[-1]).ToLower()
            }
            if ($displayName -match '(\S+)\-(\S+)\s(\S+)\-(\S+)') {
                $combinations += ($Matches[1] + "-" + $Matches[2] + "." + $Matches[3]).ToLower()
                $combinations += ($Matches[1] + "-" + $Matches[2] + "." + $Matches[4]).ToLower()
                $combinations += ($Matches[1] + "." + $Matches[3] + "-" + $Matches[4]).ToLower()
                $combinations += ($Matches[2] + "." + $Matches[3] + "-" + $Matches[4]).ToLower()
                $combinations += ($Matches[2] + "-" + $Matches[1] + "." + $Matches[4]).ToLower()
                $combinations += ($Matches[2] + "-" + $Matches[1] + "." + $Matches[3]).ToLower()
                $combinations += ($Matches[2] + "." + $Matches[4] + "-" + $Matches[3]).ToLower()
                $combinations += ($Matches[1] + "." + $Matches[4] + "-" + $Matches[3]).ToLower()
            }
            if ($displayName -match '(\S+)\s(\S+)\s(\S+)') {
                $displayNameReversed = "$($Matches[3]) $($Matches[2]) $($Matches[1])"
                $normalizedDisplayName = $displayName.ToLower() -replace '\s+', '.'
                $normalizedDisplayNameReversed = $displayNameReversed.ToLower() -replace '\s+', '.'
                $combinations += ($Matches[1] + $Matches[2] + "." + $Matches[3]).ToLower()
                $combinations += ($Matches[1] + "." + $Matches[2] + $Matches[3]).ToLower()
                $combinations += ($Matches[1] + $Matches[3] + "." + $Matches[2]).ToLower()
                $combinations += ($Matches[3] + "-" + $Matches[1] + "." + $displayName.Split(" ")[-2][0]).ToLower()
                $combinations += ($Matches[1] + "-" + $Matches[3]  + "." + $displayName.Split(" ")[-2][0]).ToLower()
                $combinations += ($displayName.Split(" ")[-2][0] + "." + $Matches[3] + "-" + $Matches[1]).ToLower()
                $combinations += ($displayName.Split(" ")[-2][0] + "." + $Matches[1] + "-" + $Matches[3]).ToLower()
                $combinations += ($Matches[3] + "-" + $Matches[1] + "." + $Matches[2]).ToLower()
                $combinations += ($Matches[1] + "-" + $Matches[3] + "." + $Matches[2]).ToLower()
                $combinations += ($Matches[2] + "." + $Matches[1] + "-" + $Matches[3]).ToLower()
                $combinations += ($Matches[2] + "." + $Matches[3] + "-" + $Matches[1]).ToLower()
                $combinations += ($displayName[0] + "." + $displayName.Split(" ")[-2] + "-" + $displayName.Split(" ")[-1]).ToLower()
                $combinations += ($displayName[0] + "." + $displayName.Split(" ")[-1] + "-" + $displayName.Split(" ")[-2]).ToLower()
                $combinations += ($displayName.Split(" ")[-2] + "-" + $displayName.Split(" ")[-1]  + "." + $displayName[0]).ToLower()
                $combinations += ($displayName.Split(" ")[-1] + "-" + $displayName.Split(" ")[-2]  + "." + $displayName[0]).ToLower()
                $combinations += ($displayName.Split(" ")[0] + "." + $displayName.Split(" ")[-2] + "-" + $displayName.Split(" ")[-1]).ToLower()
                $combinations += ($displayName.Split(" ")[0] + "." + $displayName.Split(" ")[-1] + "-" + $displayName.Split(" ")[-2]).ToLower()
                $combinations += ($displayName.Split(" ")[-2] + "-" + $displayName.Split(" ")[-1]  + "." + $displayName.Split(" ")[0]).ToLower()
                $combinations += ($displayName.Split(" ")[-1] + "-" + $displayName.Split(" ")[-2]  + "." + $displayName.Split(" ")[0]).ToLower()
                $combinations += ($displayNameReversed[0] + "." + $displayNameReversed.Split(" ")[-2] + "-" + $displayName.Split(" ")[0]).ToLower()
                $combinations += ($displayNameReversed[0] + "." + $displayName.Split(" ")[0] + "-" + $displayNameReversed.Split(" ")[-2]).ToLower()
                $combinations += ($displayNameReversed.Split(" ")[-2] + "-" + $displayName.Split(" ")[0] + "." + $displayNameReversed[0]).ToLower()
                $combinations += ($displayName.Split(" ")[-2] + "-" + $displayNameReversed.Split(" ")[0] + "." + $displayNameReversed[0]).ToLower()
                $combinations += ($displayNameReversed.Split(" ")[0] + "." + $displayNameReversed.Split(" ")[-2] + "-" + $displayName.Split(" ")[0]).ToLower()
                $combinations += ($displayNameReversed.Split(" ")[0] + "." + $displayName.Split(" ")[0] + "-" + $displayNameReversed.Split(" ")[-2]).ToLower()
                $combinations += ($displayNameReversed.Split(" ")[-2] + "-" + $displayName.Split(" ")[0] + "." + $displayNameReversed.Split(" ")[0]).ToLower()
                $combinations += ($displayName.Split(" ")[-2] + "-" + $displayNameReversed.Split(" ")[0] + "." + $displayNameReversed.Split(" ")[0]).ToLower()
                $combinations += ($displayName.Split(" ")[-2][0] + "." + $displayName.Split(" ")[-1]).ToLower()
                $combinations += ($displayName.Split(" ")[-2][0] + "." + $displayName.Split(" ")[0]).ToLower()
             }
                       
             $combinations += ($displayName[0] + "." + $displayName.Split(" ")[-1]).ToLower()
             $combinations += ($displayNameReversed[0] + "." + $displayNameReversed.Split(" ")[-1]).ToLower()
        }
        
        $userIdsForDisplayName = @() 
        
        foreach ($combination in $combinations) {
                           
        
          [System.Collections.ArrayList]$domainNameSuffixes = @(
              "aldi-nord.com",
              "aldi-nord.de",
              "aldi-techhub.pl",
              "aldi.fr",
              "aldi.pl",
              "aldi.be",
              "aldi.nl",
              "aldi.es",
              "aldi.dk",
              "aldi.pt",
              "aldi.lu",
              "ext.aldi-nord.de"
          ) 
  
          foreach ($domainSuffix in $domainNameSuffixes) {
              $userPrincipalName = "$($combination)@$domainSuffix"
  
              $GraphAPIEndpoint = "https://graph.microsoft.com/v1.0/users/$userPrincipalName"
  
              $restInputObject = @{
                  method = 'GET'
                  uri    = $GraphAPIEndpoint
                  header = @{
                      "Content-Type" = "application/json"
                  }
              }
  
              try {
                  $user = Invoke-RESTCommand @restInputObject -ErrorAction Stop
                  if ($user -ne $null -and $user.id -ne $null) {
                      $userIdsForDisplayName += $user.id
                      Write-Verbose "$userPrincipalName" -Verbose
                  }
              }
              catch {
                  Write-Verbose "Error checking user [$userPrincipalName]: $($_.Exception.Message)" -Verbose
              }
  
          }
  
          if ($userIdsForDisplayName.Count -gt 0) {
              $userIds += $userIdsForDisplayName
          }
       }
    }
    return $missingMembers, $userIds
}

# Function to add missing members to a notification group
#This helper function is called in last loop of main function. 
function Add-MissingMembersToNotificationGroup {
    <# 
        Parameters:
            - userIds: Array of missing member IDs
            - groupId: Azure AD group ID
            - groupName: Display name of the Azure AD group
        Uses:
            - Invoke-RESTCommand
    #>
    param (
        [string[]]$userIds,
        [string]$groupId,
        [string]$groupName
    )

    foreach ($memberId in $userIds) {
        
        $restUri = "https://graph.microsoft.com/v1.0/groups/$groupId/members/$memberId"

        $headers = @{
            "Content-Type"  = "application/json"
        }
    
        # Check if the member already exists in the group
        $foundUser = Invoke-RESTCommand $restUri -Method 'GET' -Header $headers -ErrorAction SilentlyContinue
        
        if ($foundUser) {
            Write-Verbose "Member already exists in the group: $groupId, groupName:$groupName . Skipping the addition of the member to group." -Verbose
        } 
        else {
            Write-Verbose "Member not found in Group: $groupId , groupName:$groupName . Adding the $memberId to group." -Verbose
    
            $body = @{
                "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$memberId"
            }   
            $ref = '$ref'
            $uri = "https://graph.microsoft.com/v1.0/groups/$groupId/members/$ref"

            $response = Invoke-RESTCommand $uri -Method 'POST' -Header $headers -Body ($body | ConvertTo-Json) -ErrorAction SilentlyContinue
   
            if (-not [String]::IsNullOrEmpty($response.error)) {
                    $errorMsg = $response.error.message
                    if ($errorMsg -match "One or more added object references already exist for the following modified properties: ") {
                        Write-Verbose "Member already exists in the group: $groupId, groupName:$groupName. Skipping the addition of the member to the group." -Verbose
                        $global:lastExitCode = 0
                    } else {
                        Write-Verbose "An error occurred while adding the member to the group: $($response.Exception.Message)" -Verbose
                    }
                } else {
                    Write-Verbose "Member $memberId added to the group $groupId , groupName $groupName successfully." -Verbose
                }
            
        }
        
    }
}

$groupNames = $groupNames -split ','

$notificationMembers, $contributorOwnerReaderMembers, $notificationgroupID, $notificationgroupName= Get-GroupMembers -groupNames  $groupNames

$missingMembers, $userIds = Get-MissingMembersAndIds -contributorOwnerReaderMembers $contributorOwnerReaderMembers -notificationMembers $notificationMembers 

if ($missingMembers.Count -gt 0) {
    Write-Verbose "Members not present in notification group: $missingMembers" -Verbose 
    Write-Verbose "IDs of Members not present in notification group: $userIds" -Verbose  
    Add-MissingMembersToNotificationGroup -userIds $userIds -groupName $notificationgroupName -groupId $notificationgroupID
} else {
    Write-Verbose "No missing members found." -Verbose
}

}

# Function to add missing members to the 'All Projects' notification group
# This function is called in Get-RoleAssignmentsAndWorkloadTeams function
function Add-MissingMembersToAllProjectsNotificationGroup {
    <# 
        Parameters:
            - userIds: Array of missing member IDs
            - groupId: Azure AD group ID
            - groupName: Display name of the Azure AD group
        Uses:
            - Invoke-RESTCommand
    #>
    param (
        [string[]]$userIds,
        [string]$groupId,
        [string]$groupName
    )
    try {
      foreach ($memberId in $userIds) {
        
        $restUri = "https://graph.microsoft.com/v1.0/groups/$groupId/members/$memberId"

        $headers = @{
            "Content-Type"  = "application/json"
        }
    
        # Check if the member already exists in the group
        $foundUser = Invoke-RESTCommand $restUri -Method 'GET' -Header $headers -ErrorAction SilentlyContinue
        
        if ($foundUser.PSObject.Properties.Name -contains 'displayName') {
            Write-Verbose "Member already exists in the group: $groupId, groupName:$groupName . Skipping the addition of the member $memberId to group." -Verbose
        } 
        else {
            Write-Verbose "Member not found in Group: $groupId , groupName:$groupName . Adding the $memberId to group." -Verbose
    
            $body = @{
                "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$memberId"
            }   
            $ref = '$ref'
            $uri = "https://graph.microsoft.com/v1.0/groups/$groupId/members/$ref"

            $response = Invoke-RESTCommand $uri -Method 'POST' -Header $headers -Body ($body | ConvertTo-Json) -ErrorAction SilentlyContinue
   
            if (-not [String]::IsNullOrEmpty($response.error)) {
                    $errorMsg = $response.error.message
                    if ($errorMsg -match "One or more added object references already exist for the following modified properties: ") {
                        Write-Verbose "Member already exists in the group: $groupId, groupName:$groupName. Skipping the addition of the member to the group." -Verbose
                        $global:lastExitCode = 0
                    } else {
                        Write-Verbose "An error occurred while adding the member to the group: $($response.Exception.Message)" -Verbose
                    }
                } else {
                    Write-Verbose "Member $memberId added to the group $groupId , groupName $groupName successfully." -Verbose
                }
            
            }
        
        }
    } catch {
        Write-Error "An error occurred in Add-MissingMembersToAllProjectsNotificationGroup: $_"
    }
}

# Function to get members of all specified subscription notification groups
# This function is called in Get-RoleAssignmentsAndWorkloadTeams function
function Get-AllProjectsandSubscriptionNotificationGroupMembers {
    <# 
        Parameters:
            - groupNames: Array of group names
        Returns: Array of unique user object IDs across all specified notification groups
    #>

    [CmdletBinding(SupportsShouldProcess = $true)]
    param (
        [Parameter(Mandatory = $true,
            HelpMessage = "Subscription Notification Group Names")]
        [string[]]$groupNames
    )

    function Get-GroupIdByDisplayName($displayName) {
        $graphApiUrl = "https://graph.microsoft.com/v1.0/groups"
        $query = "?`$filter=displayName eq '$displayName'"
        $graphApiUrlquery = "$graphApiUrl$query"
        $group = Invoke-RESTCommand -Method 'GET' -Uri $graphApiUrlquery
        if ($group.value.Count -gt 0) {
            return $group.value[0].id
        } else {
            return $null
        }
    }

    function Get-GroupMembersWithNamesAndIDs($groupId) {
        $graphApiUrl = "https://graph.microsoft.com/v1.0/groups/$groupId/members"
        $groupMembers = Invoke-RESTCommand -Method 'GET' -Uri $graphApiUrl
        $userObjectIds = @()
        foreach ($member in $groupMembers.value) {
            $userObjectId = $member.id
            $userObjectIds += $userObjectId
        }
        return $userObjectIds
    }

    function Get-MissingMembersObjectIds {
        <# 
            Parameters:
                - groupNames: Array of group names
            Uses:
                - Get-GroupIdByDisplayName
                - Get-GroupMembersWithNamesAndIDs
            Returns:
                - serObjectIdsAllNotificationGroups: Unique Object ID of the notification group members
        #>
        param (
            $groupNames
        )
        $userObjectIdsAllNotificationGroups = @()
        
        foreach ($groupName in $groupNames) {
          $groupID = Get-GroupIdByDisplayName -displayName $groupName
          $userObjectIds = Get-GroupMembersWithNamesAndIDs -groupId $groupID
          $userObjectIdsAllNotificationGroups += $userObjectIds
        }
        return $userObjectIdsAllNotificationGroups | Select-Object -Unique
    }
    Get-MissingMembersObjectIds -groupNames $groupNames
}

# Entry point to execute the main functionality
Get-RoleAssignmentsAndWorkloadTeams