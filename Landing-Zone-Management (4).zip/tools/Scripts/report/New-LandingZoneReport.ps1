<#
.SYNOPSIS
Creates LZ Versions report

.DESCRIPTION
Creates LZ Versions report in specified location

.PARAMETER CurrentLZVersion
Required. Current version of Landing Zones

.PARAMETER Path
Required. Path where report files will be stored

.PARAMETER Name
Required. Report file name

.EXAMPLE
New-LandingZoneReport -CurrentLZVersion "2.1.0" -Path ".\reports\" -Name "lzReport.xlsx"

Returns report files
#>

function New-LandingZoneReport {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $currentLZVersion,

        [Parameter(Mandatory = $true)]
        [string] $path,

        [Parameter(Mandatory = $true)]
        [string] $name
    )

    if (!(Test-Path -path $path)) {
        Write-Verbose ("Path [{0}] not found" -f $path) -Verbose
        throw "Incorrect Path. Directory must be created before use of New-LandingZoneReport"
    }

    # Query subscription data with Resource Graph
    $allLandingZonesQuery = "ResourceContainers 
    | where type=='microsoft.resources/subscriptions'"
    
    $allLandingZones = Search-AzGraph -Query $allLandingZonesQuery -First 1000 -Verbose
    
    # Parse data and build reports
    $lzVersionTagValue = "LZv"+$currentLZVersion
    $updatedLzCount = ($allLandingZones | where {(($_.properties.state -eq "Enabled") -and ($_.tags.ccoe_lz_version -eq $lzVersionTagValue ))}).count
    $requiredUpdateCount = ($allLandingZones | where {(($_.properties.state -eq "Enabled") -and (($_.tags.ccoe_lz_version -ne $lzVersionTagValue ) -and ($_.tags.ccoe_lz_version -ne $null)))}).count
    $numberOfLzTotal = ($allLandingZones | where {($_.properties.state -eq "Enabled") -and ($_.tags.ccoe_lz_version -ne $null)}).count
    $updateRequired = $allLandingZones | 
        Where-Object {$_.properties.state -eq "Enabled"} |
        Where-Object {(($_.tags.ccoe_lz_version -ne $lzVersionTagValue) -and ($_.tags.ccoe_lz_version -ne $null))} |
        Where-Object {(($_.properties.managementGroupAncestorsChain[0].displayName -like '*online') -or ($_.properties.managementGroupAncestorsChain[0].displayName -like '*corp'))} |
        Select-Object @{n="Name";e={$_.name}},
            @{n="Version";e={$_.tags.ccoe_lz_version}}, 
            @{n="Stage";e={$_.tags.ccoe_stage}},
            @{n="Parent MG";e={$_.properties.managementGroupAncestorsChain[0].displayName}},
            @{n="Technical contact";e={$_.tags.ccoe_technicalcontact}},
            @{n="Owner";e={$_.tags.ccoe_owner}},
            @{n="Team mailbox";e={$_.tags.ccoe_workloadteam}}

    $updateAndMoveRequired = $allLandingZones | 
        Where-Object {$_.properties.state -eq "Enabled"} |
        Where-Object {(($_.tags.ccoe_lz_version -ne $lzVersionTagValue) -and ($_.tags.ccoe_lz_version -ne $null))} |
        Where-Object {(($_.properties.managementGroupAncestorsChain[0].displayName -notlike '*online') -and ($_.properties.managementGroupAncestorsChain[0].displayName -notlike '*corp'))} |
        Select-Object @{n="Name";e={$_.name}},
            @{n="Version";e={$_.tags.ccoe_lz_version}}, 
            @{n="Stage";e={$_.tags.ccoe_stage}},
            @{n="Parent MG";e={$_.properties.managementGroupAncestorsChain[0].displayName}},
            @{n="Technical contact";e={$_.tags.ccoe_technicalcontact}},
            @{n="Owner";e={$_.tags.ccoe_owner}},
            @{n="Team mailbox";e={$_.tags.ccoe_workloadteam}}

    $nonStandardSubscriptions = $allLandingZones | 
        Where-Object {$_.properties.state -eq "Enabled"} |
        Where-Object {$_.tags.ccoe_lz_version -notlike 'LZv*'} |
        Where-Object {($_.properties.managementGroupAncestorsChain[0].name -notlike '*mg-platform*')} |
        Where-Object {($_.properties.managementGroupAncestorsChain[1].name -notlike '*mg-platform*')} |
        Where-Object {($_.properties.managementGroupAncestorsChain[0].name -notlike '*mg-deep*')} |
        Select-Object @{n="Name";e={$_.name}},
            @{n="Parent MG";e={$_.properties.managementGroupAncestorsChain[0].displayName}},
            @{n="Application name";e={$_.tags.ApplicationName}},
            @{n="Owner";e={$_.tags.Owner}},
            @{n="Department";e={$_.tags.Department}},
            @{n="billing_invoice_recipient_unit";e={$_.tags.billing_invoice_recipient_unit}}
    
    $disabledLandingZones = $allLandingZones | 
        Where-Object {$_.properties.state -eq "Disabled"} |
        Where-Object {(($_.tags.ccoe_lz_version -ne $null))} |
        Select-Object @{n="Name";e={$_.name}},
            @{n="Version";e={$_.tags.ccoe_lz_version}}, 
            @{n="State";e={$_.properties.state}},
            @{n="Stage";e={$_.tags.ccoe_stage}},
            @{n="Parent MG";e={$_.properties.managementGroupAncestorsChain[0].displayName}},
            @{n="Technical contact";e={$_.tags.ccoe_technicalcontact}},
            @{n="Owner";e={$_.tags.ccoe_owner}},
            @{n="Team mailbox";e={$_.tags.ccoe_workloadteam}}

    $allLZDetails = $allLandingZones | 
        Where-Object {$_.properties.state -eq "Enabled"} |
        Where-Object {($_.tags.ccoe_lz_version -ne $null)} |
        Select-Object @{n="Name";e={$_.name}},
            @{n="Version";e={$_.tags.ccoe_lz_version}}, 
            @{n="Stage";e={$_.tags.ccoe_stage}},
            @{n="Parent MG";e={$_.properties.managementGroupAncestorsChain[0].displayName}},
            @{n="Technical contact";e={$_.tags.ccoe_technicalcontact}},
            @{n="Owner";e={$_.tags.ccoe_owner}},
            @{n="Team mailbox";e={$_.tags.ccoe_workloadteam}},
            @{n="Status";e={$_.properties.state}}


    Write-Verbose ("Current LZ Version {0}" -f $currentLZVersion) -Verbose
    Write-Verbose ("Up to date: {0}" -f $updatedLzCount) -Verbose
    Write-Verbose ("Required actions: {0}" -f $requiredUpdateCount) -Verbose
    Write-Verbose ("In total: {0}" -f $numberOfLzTotal) -Verbose

    # Create report file
    $reportPathAndName = ($path+'\'+$name+'.xlsx')
    $updateRequired | Export-Excel -Path $reportPathAndName  -Append -WorksheetName "UpdateRequired"
    $updateAndMoveRequired | Export-Excel -Path $reportPathAndName  -Append -WorksheetName "UpdateAndMoveRequired"
    $nonStandardSubscriptions | Export-Excel -Path $reportPathAndName  -Append -WorksheetName "NonStandardSubscriptions"
    $disabledLandingZones | Export-Excel -Path $reportPathAndName  -Append -WorksheetName "DisabledLandingZones"
    $allLZDetails | Export-Excel -Path $reportPathAndName  -Append -WorksheetName "allLZDetails"

    # Collect statistics for output
    $output = @{} 
    $output.Add("currentLZVersion",$currentLZVersion)
    $output.Add("updatedLzCount",$updatedLzCount)
    $output.Add("requiredUpdateCount",$requiredUpdateCount)
    $output.Add("numberOfLzTotal",$numberOfLzTotal)

    return $output
}


