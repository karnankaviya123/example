
<#
    .SYNOPSIS
    Creates VNet connection.

    .DESCRIPTION
    Creates VNet connection between workload VNet and Virtual Hub. Function requires Get-VirtualNetworkConnection to get connection details

    .PARAMETER virtualNetworkResourceId
    Mandatory. Id of virtual network to be peered with Virtual HUB

    .PARAMETER connectionName
    Mandatory. Name of connection to be deployed

    .EXAMPLE
    ./tools/Scripts/New-ConnectionDeployment.ps1  -WhatIf:$true
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $virtualNetworkResourceId,
    [Parameter(Mandatory = $true)]
    [string] $connectionName
)

$virtualHubSubscriptionName = "sub-de-ohg-ats-dcs-cnct-prd"
$virtualHubName = "hub-we-prod-01"

# Get Virtual network ID for deployment
$virtualNetworksGraphQuery = "resources 
| where type == 'microsoft.network/virtualnetworks' 
| where id == '{0}'"-f $virtualNetworkResourceId

$remoteVirtualNetwork = Search-AzGraph -Query $virtualNetworksGraphQuery

if (-not $remoteVirtualNetwork){
    Write-Verbose ("Virtual Network not found. VNet Resource Id" -f $virtualNetworkResourceId) -Verbose
    throw "Virtual Network not found"
}
# Deployment template for VNet Connection
$templateParameterObject = @{
    virtualNetworkResourceId = $virtualNetworkResourceId
    connectionName           = $connectionName
}

# Deployment parameters
$deploymentName          = "LZ-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
$templateFile            = "$PSScriptRoot/../.bicep/deployVNetConnection.bicep"
$location                = "westeurope"

Write-Verbose "Invoke deployment with parameters" -Verbose
Write-Verbose ($templateParameterObject | ConvertTo-Json | Out-String) -Verbose

$deploymentParams = @{
    DeploymentName          = "LZ-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
    TemplateFile            = "$PSScriptRoot/../.bicep/deployVNetConnection.bicep"
    location                = "westeurope"
    TemplateParameterObject = $templateParameterObject 
    Verbose                 = $true
}

Write-Verbose "Invoke deployment with" -Verbose
Write-Verbose ($deploymentParams | ConvertTo-Json | Out-String) -Verbose

Test-AzSubscriptionDeployment @deploymentParams 

if ($PSCmdlet.ShouldProcess("Subscription-level deployment for subscription [$subscriptionName]", "Invoke")) {
    $res = New-AzSubscriptionDeployment @deploymentParams
    Write-Verbose ($res.Outputs | ConvertTo-Json -Depth 10 | Out-String) -Verbose
}
else {
    New-AzSubscriptionDeployment @deploymentParams -WhatIf
}