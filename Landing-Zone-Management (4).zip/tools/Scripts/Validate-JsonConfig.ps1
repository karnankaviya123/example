<#
    .SYNOPSIS
    Validates a JSON configuration file againt a specified schema file

    .DESCRIPTION
    This function validates a JSON configuration file againt a given JSON schema file. 
    It checks if the current/new configuration adheres to the naming convention.

    .PARAMETER JsonFilePath
    Mandatory. Specifies the path to the JSON Configuration file to be validated.

    .PARAMETER SchemaFilePath
    Mandatory. Specifies the path to the JSON Schema file used for validation.

    .EXAMPLE
    ./tools/Scripts/Validate-JsonConfig.ps1 JsonFilePath ./lzconfig.json -SchemaFilePath $(path/to/lzconfig.schema.jsn
    )
#>

function Validate-JsonConfig {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$JsonFilePath,

        [Parameter(Mandatory = $true)]
        [string]$SchemaFilePath
    )

    if (!(Test-Path -path $SchemaFilePath)) {
        Write-Verbose ("LZ Config schema [{0}] not found" -f $SchemaFilePath) -Verbose
        throw "JSON schema not found"
    }

    Write-Verbose ("LZ Config schema [{0}] found" -f $SchemaFilePath) -Verbose
    $JsonValidation = $(Test-Json -Json $(Get-content -RAW $JsonFilePath) -Schema $(Get-content -RAW $SchemaFilePath) -ErrorAction Continue 2>&1)

    $errorMessages = $JsonValidation -split "`n" | Where-Object { $_ -ne "" }
    
    $errorsPrinted = @()  
    $errorsToLog = @()   
    
    if ($errorMessages -ne $null) {
        foreach ($errorMessage in $errorMessages) {
            if ($errorMessage -ne "False") {  
                if ($errorMessage -notin $errorsPrinted) {
                    $errorsToLog += $errorMessage  
                    $errorsPrinted += $errorMessage  
                }
            }
        }
    
        $additionalErrors = @()
        foreach ($errorMessage in $errorMessages) {  
            if ($errorMessage -match "#/ConfigVersion") {
                $additionalErrors += "Error: The 'ConfigVersion' name should follow the naming convention. The names should be in the format X.X.X where X can be from 0-9 and it can be single or multiple digits."
            }
            if ($errorMessage -match "#/deploymentLock") {
              $additionalErrors += "Error: The 'deploymentLock' field should follow the naming convention. It accepts Boolean value. Default Value is True"
            }
            if ($errorMessage -match "#/LZVersion") {
              $additionalErrors += "Error: The 'LZVersion' field should follow the naming convention. The names should be in the format X.X.X where X can be from 0-9 and it can be single or multiple digits."
            }
            if ($errorMessage -match "#/project") {
                $additionalErrors += "Error: The 'project' name should follow the naming convention. The names should be between 3 - 4 Alphanumeric characters which can include hyphens, parentheses and underscores."
            }
            if ($errorMessage -match "#/stage") {
              $additionalErrors += "Error: The 'stage' field should follow the naming convention. Allowed values for this field are dev, tst, int, prd, build, shr"
            }
            if ($errorMessage -match "#/context") {
              $additionalErrors += "Error: The 'context' field should follow the naming convention. The names should be between 1 - 32 Alphanumeric characters which can include hyphens, parentheses and underscores. This is optional Parameter."
            }
            if ($errorMessage -match "#/number") {
                $additionalErrors += "Error: The 'number' field should follow the naming convention. The allowed range of values for this field is between 001-999"
            }
            if ($errorMessage -match "#/MgmtGrId") {
              $additionalErrors += "Error: The 'MgmtGrId' field should follow the naming convention. Allowed values for this field are mg-corp, mg-online, mg-sap, dev-mg-corp, dev-mg-online, dev-mg-sap, build-mg-corp, build-mg-online, build-mg-sap"
            }
            if ($errorMessage -match "#/vnetAddressPrefix") {
              $additionalErrors += "Error: The 'vnetAddressPrefix' field should follow the proper IP address format."
            }
            if ($errorMessage -match "#/vnetDNSServers") {
              $additionalErrors += "Error: The 'vnetDNSServers' field should follow the proper IP address format."
            }
            if ($errorMessage -match "#/Tag") {
                if ($errorMessage -match "#/Tag.ccoe_project") {
                    $additionalErrors += "Error: The 'ccoe_project' tag should follow the naming convention. The names should be between 3 - 4 Alphanumeric characters which can include hyphens, parentheses and underscores."
                }
                if ($errorMessage -match "#/Tag.ccoe_owner") {
                    $additionalErrors += "Error: The 'ccoe_owner' tag should be a valid email address."
                }
                if ($errorMessage -match "#/Tag.ccoe_billingID") {
                    $additionalErrors += "Error: The 'ccoe_billingID' tag is not proper. The allowed billing ID tag value is between 1-11 Alphanumeric characters which can include hyphens, parentheses and underscores."
                }
                if ($errorMessage -match "#/Tag.ccoe_workloadteam") {
                  $additionalErrors += "Error: The 'ccoe_workloadteam' tag should be a valid email address."
                }
                if ($errorMessage -match "#/Tag.ccoe_technicalcontact") {
                  $additionalErrors += "Error: The 'ccoe_technicalcontact' tag should be a valid email address."
                }
              }
            if ($errorMessage -match "#/ResourceNames") {
                if ($errorMessage -match "#/ResourceNames.rgVnet") {
                    $additionalErrors += "Error: Name of the Resource Group for the VNet is not following the naming convention. Correct format rg-<project>-<stage>[-<Region>]-<context>-<###> where region, context, and ### are optional parameters. Check each component. If everything follows the naming convention and it is still failing, then reduce the context string size."
                }
                if ($errorMessage -match "#/ResourceNames.vnetName") {
                    $additionalErrors += "Error: Name of the VNet is not following the naming convention. Correct format vnet-<project>-<stage>[-<Region>]-<context>-<###> where region, context, and ### are optional parameters. Check each component. If everything follows the naming convention and it is still failing, then reduce the context string size."
                }
                if ($errorMessage -match "#/ResourceNames.rgRsvWestEurope") {
                    $additionalErrors += "Error: Name of the Resource Group for the Recovery Services Vault WEU is not following the naming convention. Correct format rg-<project>-<stage>[-<Region>]-<context>-<###> where region, context, and ### are optional parameters. Check each component. If everything follows the naming convention and it is still failing, then reduce the context string size."
                }
                if ($errorMessage -match "#/ResourceNames.rgRsvNorthEurope") {
                    $additionalErrors += "Error: Name of the Resource Group for the Recovery Services Vault NEU is not following the naming convention. Correct format rg-<project>-<stage>[-<Region>]-<context>-<###> where region, context, and ### are optional parameters. Check each component. If everything follows the naming convention and it is still failing, then reduce the context string size."
                }
                if ($errorMessage -match "#/ResourceNames.rsvNameWestEurope") {
                    $additionalErrors += "Error: Name of the Recovery Services Vault WEU is not following the naming convention. Check each component. If everything follows the naming convention and it is still failing, then reduce the context string size."
                }
                if ($errorMessage -match "#/ResourceNames.rsvNameNorthEurope") {
                    $additionalErrors += "Error: Name of the Recovery Services Vault NEU is not following the naming convention. Correct format rsv-<project>-<stage>-<region>. Check each component. If everything follows the naming convention and it is still failing, then reduce the context string size."
                }
            }
        }
    
        foreach ($additionalError in $additionalErrors) {
            Write-Host $additionalError
        }
    
        if ($additionalErrors -gt 0) {  
            throw "lzconfig.json Not valid"
        } else {
            Write-Verbose ("JSON validation completed successfully") -Verbose
        }
    }
    else {
        Write-Verbose ("JSON validation completed successfully") -Verbose
    }                                                             
}