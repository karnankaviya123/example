
<#
.SYNOPSIS
Exports tags of a subscription, its resource groups and resources.

.DESCRIPTION
Exports tags of a subscription, its resource groups and resources into a JSON file. If the file exist, it will be overwritten.

.PARAMETER subscriptionId
Required. Id of Subscription.

.PARAMETER outputFile
Required. Output file. If the file exist, it will be overwritten.

.EXAMPLE
Export-SubscriptionTags -subscriptionId '11111111-1111-1111-1111-1111' -outputFile 'C:\Aldi\output.json'

#>
function Export-SubscriptionTags {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $subscriptionId,

        [Parameter(Mandatory = $false)]
        [string] $outputFile = "$subscriptionId-tags.json"
    )

    Write-Verbose ("Exporting tags of the subscription [{0}]" -f $subscriptionId) -Verbose
    Write-Verbose ("Output file : [{0}]" -f $outputFile) -Verbose

    # verifying if the subscription exists
    $ResourceGraphQuery = "resourcecontainers
    | where type =~ 'microsoft.resources/subscriptions'
    | where subscriptionId =~ '{0}'
    | project id, name" -f $subscriptionId

    # running the query
    $subscriptionInfo = Search-AzGraph -Query $ResourceGraphQuery
    if ($subscriptionInfo.Count -eq 0) {
        Write-Verbose ("Subscription with the Id [{0}] not found" -f $subscriptionId) -Verbose
        throw "Subscription not found"
    }

    # creating a Azure Resource Graph query
    $ResourceGraphQuery = "resourcecontainers
    | where subscriptionId =~ '{0}'
    | project id, name, type, resourceGroup, tags
    | union (resources
    | where subscriptionId =~ '{0}'
    | project id, name, type, resourceGroup, tags)" -f $subscriptionId

    # running the query
    $tagsInfo = Search-AzGraph -Query $ResourceGraphQuery
    $tagsInfo | ConvertTo-Json -Depth 99 | Out-File -FilePath $outputFile

    Write-Verbose ("Number of exported entries: [{0}]" -f $tagsInfo.Count) -Verbose


}

# # example
# # running against all subscriptions in mg-online and mg-corp
# $ResourceGraphQuery = "resourcecontainers
# | where type =~ 'microsoft.resources/subscriptions'
# | where properties.state =~ 'Enabled'
# | project id, name, subscriptionId" -f $subscriptionId

# $subscriptionInfo = Search-AzGraph -Query $ResourceGraphQuery -ManagementGroup 'mg-corp', 'mg-online'

# foreach($sub in $subscriptionInfo) {
#         Export-SubscriptionTags -subscriptionId $sub.subscriptionId -outputFile ".\TagsBackup\$($sub.name)-$($sub.subscriptionId)-tags.json"
# }

