
<#
    .SYNOPSIS
    Applies tags on Subscription

    .DESCRIPTION
    Applies set of tags on Subscription

    .PARAMETER lzconfigPath
    Mandatory. The lzconfig.json with the fundamental deployment configuration (e.g. Project & Stage)
    
    .PARAMETER subscriptionName
    Mandatory. Name of subscription

    .EXAMPLE
    ./tools/Scripts/New-LandingZone.ps1 -lzconfigPath:"lzconfig.json" -WhatIf:$true
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $lzconfigPath,

    [Parameter(Mandatory = $true)]
    [string] $subscriptionName
)

Write-Verbose ("Subscription name: {0}" -f $subscriptionName ) -Verbose

#Read Config
$config = Get-Content -Raw -Path $lzconfigPath | ConvertFrom-Json -Depth 99 -AsHashtable

#Add ccoe_lz_version tag to deployment parameters
If ($config.ContainsKey('Tag')) {
    $config.Tag.Add("ccoe_lz_version",$config.lzVersion) # FIX NEEDED
}

Write-Verbose "Processing Config: " -Verbose
Write-Verbose ($config | ConvertTo-Json) -Verbose

$templateParameterObject = @{
    Tags    = $config.Tag
}

$deploymentParams = @{
    DeploymentName          = "LZ-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
    TemplateFile            = "$PSScriptRoot/../.bicep/deployTags.bicep"
    location                = "westeurope"
    TemplateParameterObject = $templateParameterObject 
    Verbose                 = $true
}

Write-Verbose "Invoke deployment with" -Verbose
Write-Verbose ($deploymentParams | ConvertTo-Json | Out-String) -Verbose

Test-AzSubscriptionDeployment @deploymentParams 

if ($PSCmdlet.ShouldProcess("Subscription-level deployment for subscription [$subscriptionName]", "Invoke")) {
    $res = New-AzSubscriptionDeployment @deploymentParams
    Write-Verbose ($res.Outputs | ConvertTo-Json -Depth 10 | Out-String) -Verbose
}
else {
    New-AzSubscriptionDeployment @deploymentParams -WhatIf
}

