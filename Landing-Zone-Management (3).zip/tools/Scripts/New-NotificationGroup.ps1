


[CmdletBinding(SupportsShouldProcess = $true)]
param (
    [Parameter(Mandatory = $true,
        HelpMessage = "Group Owner UPN")]
    [string]$groupOwnerUPN,

    [Parameter(Mandatory = $true,
        HelpMessage = "Display name of the group.")]
    [string]$displayName,

    [Parameter(Mandatory = $true,
        HelpMessage = "Subscription Owner UPN")]
    [string]$subscriptionOwnerUPN,

    [Parameter(Mandatory = $true,
        HelpMessage = "WhatIf value")]
    [string]$validateOnly
)


function Invoke-RESTCommand {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $method,
        [Parameter(Mandatory = $true)]
        [string] $uri,
        [Parameter(Mandatory = $false)]
        [string] $body,
        [Parameter(Mandatory = $false)]
        [hashtable] $header
    )
    try {
        $inputObject = @(
            '--method', $method,
            '--uri', $uri
        )
        # Build Body
        # ---------
        if ($body) {
            $tmpPath = Join-Path $PSScriptRoot ("REST-$method-{0}.json" -f (New-Guid))
            $body | Out-File -FilePath $tmpPath -Force
            $inputObject += '--body', "@$tmpPath"
        }
        # Build Header
        # -----------
        if (-not $header) {
            $header = @{}
        }
        $compressedHeader = ConvertTo-Json $header -Depth 10 -Compress
        if ($compressedHeader.length -gt 2) {
            # non-empty
            $tmpPathHeader = Join-Path $PSScriptRoot ("REST-$method-header-{0}.json" -f (New-Guid))
            $compressedHeader | Out-File -FilePath $tmpPathHeader -Force
            $inputObject += '--headers', "@$tmpPathHeader"
        }
        # Execute
        # -------
        try {
            $rawResponse = az rest @inputObject -o json 2>&1
            #Write-Verbose  "REST response: $rawResponse" -Verbose
        }
        catch {
            $rawResponse = $_
            #Write-Verbose  "REST error: $rawResponse" -Verbose
        }
        if ($rawResponse.Exception) {
            $rawResponse = $rawResponse.Exception.Message
        }
        # Remove wrappers such as 'Conflict({...})' from the repsonse
        if (($rawResponse -is [string]) -and $rawResponse -match '^[a-zA-Z].+?\((.*)\)$') {
            if ($Matches.count -gt 0) {
                $rawResponse = $Matches[1]
            }
        }
        if ($rawResponse) {
            if (Test-Json ($rawResponse | Out-String) -ErrorAction 'SilentlyContinue') {
                return (($rawResponse | Out-String) | ConvertFrom-Json)
            }
            else {
                return $rawResponse
            }
        }
    }
    catch {
        throw $_
    }
    finally {
        # Remove temp files
        if ((-not [String]::IsNullOrEmpty($tmpPathHeader)) -and (Test-Path $tmpPathHeader)) {
            Remove-item -Path $tmpPathHeader -Force
        }
        if ((-not [String]::IsNullOrEmpty($tmpPath)) -and (Test-Path $tmpPath)) {
            Remove-item -Path $tmpPath -Force
        }
    }
}

function Get-AzureADUserObjectId {
    param (
        [string]$groupOwnerUPN
    )

    $GraphAPIEndpoint = "https://graph.microsoft.com/v1.0/users/$groupOwnerUPN"
    $restInputObject = @{
        method = 'GET'
        uri    = $GraphAPIEndpoint
        header = @{
            "Content-Type" = "application/json"
        }
    }

    try {
        $user = Invoke-RESTCommand @restInputObject -ErrorAction Stop
        $technicalContactId = $user.id
        return $technicalContactId
    }
    catch {
        Write-Verbose "Error: $($_.Exception.Message)" -Verbose
        return $null
    }

    if ($technicalContactId) {
        Write-Verbose "User ID for UPN '$groupOwnerUPN' is: $technicalContactId" -Verbose
    }
    else {
        Write-Verbose "User not found or an error occurred while fetching the ID." -Verbose
    }
}

function Add-AzureADMembersToGroup {
    param (
        [string]$memberId
    )
    # Group Object ID of AZR.AA.ALL.O365.allprojects.Notification Notification Group
    $groupId = "f955d9f8-94d4-472e-9859-402b9d96a86a"
    $restUri = "https://graph.microsoft.com/v1.0/groups/$groupId/members"
    $headers = @{
        "Content-Type"  = "application/json"
    }

    # Check if the member already exists in the group
    $existingMember = Invoke-RESTCommand $restUri -Method 'GET' -Header $headers -ErrorAction SilentlyContinue

    $foundUser = $existingMember.value | Where-Object { $_.id -eq $memberId }

    if ($foundUser) {
        Write-Verbose "Member already exists in the notification group: AZR.AA.ALL.O365.allprojects.Notification - $groupID. Skipping the addition of the member to notification group." -Verbose
    } 
    else {
        Write-Verbose "Member not found in notification Group: AZR.AA.ALL.O365.allprojects.Notification - $groupID. Adding the $memberId to notification group." -Verbose

        $body = @{
            "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$memberId"
        }   
        $ref = '$ref'
        $uri = "https://graph.microsoft.com/v1.0/groups/$groupId/members/$ref"

        $response = Invoke-RESTCommand $uri -Method 'POST' -Header $headers -Body ($body | ConvertTo-Json)

        if ($null -eq $response -or $response -eq "") {
            Write-Verbose "Member $memberId added to the notification group AZR.AA.ALL.O365.allprojects.Notification - $groupID successfully." -Verbose
        } 
        else {
            Write-Verbose "Failed to add member to the group: $($response | ConvertTo-Json -Depth 10)" -Verbose
        }
    }
}

function New-NotificationGroup {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $displayName,

        [Parameter(Mandatory = $true)]
        [string] $groupOwnerUPN,

        [Parameter(Mandatory = $true)]
        [string]$subscriptionOwnerUPN,

        [Parameter(Mandatory = $true)]
        [string] $validateOnly        
    )


    Write-Verbose  "Creating mail enabled group: $displayName" -Verbose

    # Technical Contact ID
    $technicalContactId = Get-AzureADUserObjectId -groupOwnerUPN $groupOwnerUPN

    #Get AAD User ID (Group Owner account) and add to Owners list
    [System.Collections.ArrayList]$groupOwners = @("https://graph.microsoft.com/v1.0/users/"+$technicalContactId+"/")

    $restUri = 'https://graph.microsoft.com/v1.0/groups'
    $body = @{ 
        'displayName'        = '{0}' -f $displayName
        'description'        = '{0}' -f $displayName
        'groupTypes'         = @("Unified")
        'isAssignableToRole' = 'false'
        'mailNickname'       = '{0}' -f $displayName
        'mailEnabled'        = 'true'
        'securityEnabled'    = 'false'
        'owners@odata.bind'  = $groupOwners
        'members@odata.bind' = $groupOwners
    }

    $restInputObject = @{
        method = 'POST'
        uri    = '"{0}"' -f $restUri
        header = @{
            "Content-Type" = "application/json"
        }
        body   = ConvertTo-Json $body -Depth 10 -Compress
    }
    
    If ($validateOnly -ne $true) {
        $addResponse = Invoke-RESTCommand @restInputObject -ErrorAction SilentlyContinue
    
        if (-not [String]::IsNullOrEmpty($addResponse.error)) {
            $errorMsg = $addResponse.error.message
            if ($errorMsg -match "Another object with the same value for property mailNickname already exists") {
                Write-Verbose "Group '$displayName' already exists." -Verbose
                $global:lastExitCode = 0
            } else {
                Write-Error ('Failed to create group [{0}] details because of [{1} - {2}].' -f $displayName, $addResponse.error.code, $addResponse.error.message)
            }
        } else {
            Write-Verbose  "Group successfully created ($displayName)" -Verbose
        } 
    } else {
        Write-Verbose  "Group will be created $displayName" -Verbose
    }

    
    # The automation of the notification group to allow external senders and automatic subscriibe of new members will be implemented 
    # With the user story 119071

    <#
    # Set AllowExternalSenders and AutoSubscribeNewMembers parameters
    $groupId = "9e49c277-abb8-4ea4-8140-c52bf8ff6cb5"
    $restUri = 'https://graph.microsoft.com/v1.0/groups/{0}' -f $groupId

    $body = @{ 
        'AutoSubscribeNewMembers' = 'true'
    }

    $restInputObject = @{
        method = 'PATCH'
        uri    = '"{0}"' -f $restUri
        header = @{
            "Content-Type" = "application/json"
        }
        body   = ConvertTo-Json $body -Depth 10 -Compress
    }

    #Invoke-RESTCommand @restInputObject
    #>

    # Fetching the ID of subscription owner 
    $subscriptionOwnerContactID = Get-AzureADUserObjectId -groupOwnerUPN $subscriptionOwnerUPN

    #Adding the Technical Owner and the Business Owner to the AZR.AA.ALL.O365.allprojects.Notification Notification Group
    Write-Verbose  "User ID for UPN '$groupOwnerUPN' is: $technicalContactId" -Verbose    
    $technicalContactAddition = Add-AzureADMembersToGroup -memberId $technicalContactId 

    Write-Verbose  "User ID for UPN '$subscriptionOwnerUPN' is: $subscriptionOwnerContactID" -Verbose  
    $subscriptionOwnerAddition = Add-AzureADMembersToGroup -memberId $subscriptionOwnerContactID

}

New-NotificationGroup -displayName $displayName -groupOwnerUPN $groupOwnerUPN -validateOnly $validateOnly -subscriptionOwnerUPN $subscriptionOwnerUPN