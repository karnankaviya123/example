<#
.SYNOPSIS
Create email body for LZ Report

.DESCRIPTION
The function creates mail body for landing zones rpoer

.PARAMETER CurrentLZVersion
Required. Current LZ version

.PARAMETER UpdatedLzCount
Required. Number of updated Landing Zones

.PARAMETER RequiredUpdateCount
Required. Number of Required Updates

.PARAMETER NumberOfLzTotal
Required. Total number of Landing Zones

.PARAMETER agentUsers
Required. Number of projects using shared OS image

.PARAMETER numberOfAgentPools
Required. Total number of agent pools


.EXAMPLE
New-LZReportMailBody -currentLZVersion "2.1.0" -updatedLzCount "20" -requiredUpdateCount "30" -numberOfLzTotal "50"
#>

function New-LZReportMailBody {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string] $currentLZVersion,

        [Parameter(Mandatory = $true)]
        [string]$updatedLzCount,

        [Parameter(Mandatory = $true)]
        [string]$requiredActionsCount,

        [Parameter(Mandatory = $true)]
        [string]$numberOfLzTotal,

        [Parameter(Mandatory = $true)]
        [string]$agentUsers,

        [Parameter(Mandatory = $true)]
        [string]$numberOfAgentPools,

        [Parameter(Mandatory = $true)]
        [string]$numberOfSecrets,

        [Parameter(Mandatory = $true)]
        [string]$secretsExp60,

        [Parameter(Mandatory = $true)]
        [string]$expiredSecrets
    )
    
    # Base64 encoded image (ALDI Nord logo)
    $logoImg = "/9j/4AAQSkZJRgABAQEAYABgAAD/4QBmRXhpZgAATU0AKgAAAAgABgESAAMAAAABAAEAAAMBAAUAAAABAAAAVgMDAAEAAAABAAAAAFEQAAEAAAABAQAAAFERAAQAAAABAAAOxFESAAQAAAABAAAOxAAAAAAAAYagAACxj//bAEMAAgEBAgEBAgICAgICAgIDBQMDAwMDBgQEAwUHBgcHBwYHBwgJCwkICAoIBwcKDQoKCwwMDAwHCQ4PDQwOCwwMDP/bAEMBAgICAwMDBgMDBgwIBwgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAEwASQMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AN7/AII3/wDBHT4Zf8FCf2ada8YeMtY8Yafqen+IJtLjTS7uKKExLDC4JDRsd2ZDznpivrgf8GwHwFb/AJmf4lfjqNv/APGKj/4NfE3fsI+K/wDscrn/ANJrav0nVOB9M18rk+T4GpgaVSpTTbWrsfvniX4lcU4LinHYXCY6pCnCo1GKlZJdkfm4f+DYD4Cqf+Rm+Jf/AIMbf/4xXN/Fv/g3d/Zf+A/w31rxl4y+IHjvw34X8O2zXmo6lfarbRQWsS45J8jkkkKFGWZiFAJIB/UaThe1fhh/wXy/bU1X/goR+1vpf7I/wy1gWfhHwleG/wDiFrsZMtqJ4QryK4Tl4bFclkyTJdOkWA8Q3fVZHwXgsxxSoRpJR3k7Xsl19ei8z87x3jNxZhKEq9XMqiUddZHUfD//AIJtfsA/FHwYPEXh/wCOnjLUtFku5LBLxLnbHLNEsbyIm+0G7YJY9xXIUuoOCcVd8Pf8Etf2DvF/7Q2n/CfS/jZ401D4jaoqPBoNvdeZdENb/agWxabY/wBxiQ7yu0EZxkV8+fGP4ueFf2L/ANnqPXLHTLOPQvB9umg+DtAvCsq6jdAM6C55USKpaS8vJAAsjMUwgnTZsf8ABJn4veGv+CTv7RHwz8SfHrS9RuPif+1bDcX2o+KtWkMQ8EabczqbRpmIIaa+utk1zkxm3he2Z9oDA/ZZr4WZPhaDlTg5VLO0bLdatf8AbsdZNdbJan5/wT9I/j3PpVcXPGThhublpPmfNNLRyd9LN/D8+x9wp/wbA/AVx/yM3xL/APBjb/8AxinN/wAGv/wFA/5Gb4mf+DG3/wDjFfpBDlUqQpur82/sHL/+fMfuP0z/AIi1xj/0Mav/AIEfjB/wU0/4IS/CP9jT9ijxh8RPDOt+OrzXNAFr9mi1C9hkt28y5jibcqxKTw56EV+S2Pr+Vf0gf8F7x/xqt+Jn008/+T0Ffze1+ecXYOjh8VCFCKiuXp6s/sv6OfEmZ5xkNfEZpWlVnGq0nJ3aXLF2+9s/eL/g17P/ABgh4r/7HG5/9Jrav0mMm1fwr82f+DXvj9hHxX/2ONz/AOk1tX358bvjN4b/AGefhL4i8ceL9Ut9G8M+FbCXUtRvJmwsUMa5OP7zHhVUcszKByRX6Jw/BywFGMVdtL7z+NPFp24wzG//AD9l+h8g/wDBeP8A4Knw/wDBNj9kqRfD93C3xU+IAl0vwtBw7WA2/wCkaky/3IFZdoOd00kS4K7sfln+xl+y5J+zL8LprHXJkt/H/ixf7W8bajqM+5dIgjDXC2skrLvVYELXF22TunO35vs6M2B4O+JniD/gpl+2l4m/as+IVuyaDo16dH+Hui3TrIlo9s3mwKR0aGyE3nyNgrJd3CLyBKFT9qm+8YfHz4p+Gv2XfhjBcXnxF+JtzAPFMrh3Gk2T7bmO2mYcquzF7dHkiJYEPzGVB/RnDeU08pwV6jSn8Un0uu/92mt+jl5o/j3jzM6/EWaR4Uy9tR0lWkvsw6Rv0lN2Xp5NnG6J470P9pL4geJP2jPHnhnVtf8A2a/2c5rfS9D8ONEY/wDhNNUnnU2lrPu8yKJrqQpdXjEMscK29v8AODET9BftSfDrT/2+PhhfWuoeIIdc/wCE6P8AwlXg/wAV3Si3QX8yskUk2Axit5sNaXUK5ELRq3JtVDfr38DP+CZPwv8Agx+wDD+zrJolvrXge80h9P103Ee2bXbiYZub2Q5JWd5f3ispzEVjCbRGgH4heAfhR4m/4Jv/ALX/AIi/ZL+IlzLeaXqt6dV+GmuzxCGHUprk7Y4gSMBb0IIWXdtivoVAwsrtXDkOf4fH4qq3dcvw335E78y/vJ+9Lun2ietx1wvjMLleGxOSe7Uwj5owXwyVrSg0t7x0XW/mz9DP+Dcr/gpxqX7RPwm1L4B/EyS4sfjF8GUOneVfti61fTYH8jc/J3XFq4WCb1BhfJLtj9Olfcwr+a79rHTvFnwJ+J3hn9qT4YyPp/xI+FU8J8TxyfK2pWQxaR3ciH5iBG/2K7XGfLkhkPImZf31/Ya/bE8K/t6/sx+Ffih4Pm/4lviK13XFm8ivNpN2nyz2k2OkkUgZT0yMMOGBr4vjPIng8Q8TSVoSeqXSXW3k1rHy06H3XBfFGHz3LKeNoPdarqmtGn5p6P7+p4t/wXvP/Gq34mf7un/+l0FfzeV/SH/wXv8A+UV3xM+mn/8ApdBX833l1/PPG7/2yH+H9Wf6RfRX/wCSbxP/AF+f/pED93/+DYElf2EPFXv4zuR/5LW1fKX/AAXu/bY1b/goZ+1xpn7JHwz1prPwZ4SvDffELWIgGt1uLYh5BJyA0ViBny8/vbt4olBkSME/Yv8A2z9Y/YP/AODfj4yeOPDLm38WXXjB9B0O62Kw0+7vIrWBbrDcEwqzyqCCC0agggkV4n/wTo+A3/CFfs++HJo5PtXjD4zPFrWrahcyNJI0D3Ei2UDv12jDXUnUvJMhYkxJj+gvCXIvbYGlj5/ZVo9dUrylbryrb+80fwb9KDi6ORZ5mlaC5qkqrjFd5S0ivv1fkmdR8ZPi34Z/Y9+AA1+0061g0Xwpbx+HfBWh3WZFv7wBpIo5OCGVN0t7dM21XZiuQ9zGG9F/4N5/id+zT+yh4K1/41fGT49fC/8A4Xd8TpJZJIdU1+2a+0CyeZnZZCGO24unxNKPvKoijIVlcV8ceDrrUv8Agop+2jJ4g034f/Fzxt8J/hWn2XR7DwX4Xj1u5X96XhuLuKS5t40a8kSSeRvMZtsUUIVkRSn2a0Xih2Zv+Gf/ANrPLHOf+FH6L/8ALSv0biSWHr0fqU63sr2urNvl3Sdk937z67LY/AeEcBmHDtFVfqc8VXre/VmpQXvvp7zTaitF069dP0tH/Ba79kj/AKOK+Ef/AIUMH+NfF/8AwWi1/wDZb/4K9fAbTfD/AMOvjd8J9W+PGg3W/wAB29r4gtlu9euZPlOjKzOo/wBKbYseWAWcQnIG4HyEweKM/wDJv/7WX/hkNG/+WlAj8UKysv7P/wC1orKQysvwS0ZWRhyCCNUyCDyCOlfF4PJcHhK0cRh8XacdV7r+56bPZn2VTi7OZxcJ5RUs/wDp5T/+SPKv2P8A9p6b9pH4YSa5q9usnxA8Gv8A2J480y/t2jF/5qyW4uposD5LxBPb3KD7s6ybwv2iINpf8E1f2sz/AMEVf+Cgf/CF6xqN5/wzT8c5hdadd3bBo9Cu9yxLLI2TtltnK2tyTtZ4Ta3BGzyt3Ef8FANN8Qfs0fGDwl+1to/w5+JfhOLxRqkvhL4ieHfG/hpfD8niO7a1SWS6SKK4njMV9ArkusmY7yz83AZl295+0D8DNF/am+BWteDbe4j1Cx1zS08VeDdSuE8qSG6+xfarOQ7c7ftFs32aZBlT5inkxRsP0Bww+a4Bxkrxaa9Enql5wese8Xa1z85lKpwfxFDEwTjhca0pR0/d1Xs7K+k9nbZ36JH6jf8ABeg5/wCCVnxM3c8WHI/6/oK/m93V+kv7Ov7cevftf/8ABtT8TtD8VXNxqWvfCjUNO8OpqM7Bpr6wNxbTWnmHqXjjcwFiMsIEYlmLMfzc31/HPiTgamCzb6rV3grfi9fmf7AfRTqqpwvXqLrWf/pED9Iv2Vf2etD/AGlf+Ddj43aNr3irS/A9rpXjEa5FrmqrK1jp8tt9idTOIkeTy2G5CUQsN4ODgg4f7OXxb+B/wb+HPwx03Vf2mvg1eap4HsLfTrt7NdX8i6S3uJPKKs9oGBa3KK3yjDA4zwa6b9lj/lWW/am/6+r3/wBF2Vfkf+z18BPEn7Uvx48J/DjwlbPdeJPGmpx6ZYqF3LCWJMkzDskUavK56BI2J4Br+ifCHDzqcP8AtZVnThBa2Sas467rsj+F/pHZJgs04wxmFxlPnXt3JWbTUovR6ep+rn/BEr4+/BP/AIJQfHX4lHVP2n/g74k+GPje3RLeKxj1capZy2s0n2SR1eyEZzBNIkgD8MFK5Aav0mH/AAcC/sck/wDJePC7emLS9Of/ACBXovwa+G/wv/ZD0H4Y/s56f4bmurOfwxdwWUzaAbixuo7RYVuPtk6oYkmufOlkxIQJSs3fAb8cP2UP2A5v+CeP/Bzr4L+Hf2V28H3z6nrfhSWcK63WlXGm3bRp3+aCRZbc5AOYA2AHUnjjHAZvWxGIxEpqcYuUdYrnUVb+XR2S7/geLerh4whBJq9n5XP1M/4iA/2OwcH47+FwfezvR/7Qob/g4B/Y7/6Lt4Z6dfsd9z/5Ar8r/wDg8LFjon7WfwejUWlkh8GXp2rtiBJvR9PQ/rX6OT/tKt+w5/wQA8F/F/S/Dfh7X9W8I/Djw7cxWupp5dvdNKtnAfMdRuGBKTkckgVhisjwVPAYbGQ5nKs2uXmirWdt+Xr8i6eKqOtKm0rR1vY+Qf8Agux+3F8FP+Covwj8G+Avh5+018G/DegaLq0mt6zNr6ass1zcLC0NtHGkVm+FUTTOxZgSdgAwGrjrP41/s++CtPtrPw7+0v8ACnb4a8Nx6HoDX8WrIPNttNFnayTMtqSo3osjBdxABAyK+gv+Ch3wi+Hv/BSv/gjd4R/ak1HwDpPw9+JWmaTpfiqwulhRLjyvtsQlsHlCI1xbTq7mEN0eWJ16sGf/AMHd+iWemf8ABOv4cta2lrbyN8UrJS0USoSP7G1njgV7mR5jGk6GW0HKPPOUGnyvlbtdp8ut7+VrHzXEnDODzaMauPXMqLVSKTau43tc8D+AX7KPhv8AZr/4Ny/jdfaB8RPDPxOfxd4nt5rnWPD63C6egtrizt0gX7RFFKXXazMSu3MmBnG4/mzs/wA81+j37H4/45R/Hv8A2N13/wCnS2r84twr+d/Fl1P7fqKpLmaur97SaP8ASD6JqT4UrW0/e/8AtkD9X/8Agmf+z94n/ao/4ICftBfDzwZa2994o8WateWOmQXFwtvHNKYbNgDI3yqMKeTXnf8AwS6/4JJftdf8Ezvj5qPxGh+A/wAO/H/iKTTG0vS5NQ8fQWaaOsjf6RKgWNy0kihUDcFU8wc7zj4f+F/7VPxM+COgy6V4N+IHi/wrpk05uZLXS9UltYXlIUFyqkDcQqjPsK6Rv+ChXx5J/wCSy/Ev/wAKC4/+Kr0OHvEyWWZU8rVPmhK3NfrbzunY+V46+jZmOecQ4jOqeLpxVSbkk1K6T72TVz9UPH/i/wD4Kza/8Rb7VPD/AIN+Cvhzw7LcrLbaG+oWd8YIwFzE1yzK77sHLYUjdx0Fa3xl0L9tT40ftDfCX4nX37K3wrtfFPwhvdQn0uaL4oJ/pEF7aPbXFvJ+4+6SYpQeSGhHZjn8mV/4KFfHnP8AyWT4l/8AhQXP/wAVQf8AgoX8ef8AosnxK/8ACguf/iq6v+InYa6ccLFNJrRW0as7+9rofM/8Sp5z1x9P7pf5H7Wap8bv24vEF9b3Gpfsf/BPUJrbiOSf4kQySRjOcKzWxK888d64f9nu4/bk+Bv7KfgP4T3X7LPwf8VaP4J8O6f4eMuo/EaJl1FbOGOJZZIjAyhmMQfHIBxg8V+Rf/Dwv49f9Fl+Jn/hQXP/AMVSf8PCvjyf+ay/Ev8A8KC4/wDiqx/4iRhbcv1b8/8A5Ir/AIlVzm9/r1P7pf5H6O/8FG/gj/wUc/4KJeG9J8KXnww+GfgfwDYaja6reaLpXjKGaXW5raVJolubh8ExJIiuqIijeFZtxRcSf8FWv2bf24/+CqfwA8P+AdY+Afw38G23h/xND4kjvLL4hw3jzPFZ3dqIijxoACLwtuznMeMc5H5vf8PCvjyR/wAll+Jf/hQXH/xVCf8ABQz49c/8Xl+Jf/hQXH/xVd9HxZp0nSnSw0U6TvHTq7av3tdluYy+ihm0+aMsdT95a6S/yP0Tk/Yw8f8A7Bn/AAbXfEH4f/ErTrHS/E8PiB9RaCzvkvIxDNqVu0Z8xOMkA8dRX5G7T/dr0nx7+2R8W/il4QutC8TfEzxx4g0XUNoubDUNYmuLefawZdyMxBwwBHuBXmO41+ccWZ884xzxrVnK9/Vtv9T+lfBvw/xHBuT1MtxNWNRynzJxvZLlira+h//Z"
    
    # Create dateAndTime variable to include date and time in notification in different formats
    [datetime]$dateAndTime = Get-Date

    $body = @"
        <!DOCTYPE html>
        <html>
            <head>
                <title>[ALDI] Landing Zones report</title>
                <style>
                    body {
                        background-color: #eaeaea;
                        font-family: Verdana
                    }
                    table {
                        border: hidden;
                        border: 0px;
                    }
                    td {
                        background-color: #ffffff;
                        border: hidden;
                        padding-top: 10px;
                        padding-bottom: 10px;
                    }
                    hr {
                        height: 1px;
                        width: 550px;
                        border: hidden;
                        background-color:#eaeaea;
                        border-color:#eaeaea;
                    }
                </style>
            </head>
        
            <body>
            <center>
                <table style="width:100%"><tr><td>
                    <center><table style="width:600px">
                        <tr><td style="border-bottom:0px">
                            <h2 align="right">
                                <img src="data:image/jpg;base64,$logoImg"
                                alt="ALDI Logo"></h2>
                            <h2 align="left">[ALDI] Landing Zones report</h2>
                        </td></tr>
                    </table></center>
                </table>
                <br>
                <table style="width:600px; line-height:25px">
                    <tr><td style="padding-left:30px; padding-right:30px; padding-bottom:40px; padding-top:30px; border-bottom:25px solid #eaeaea;">
                        <b><h3>Landing Zones:</h3></b>
                        <b>Current version</b> $currentLZVersion
                        <br><hr><b>Up to date</b> $updatedLzCount
                        <br><hr><b>Required actions</b> $requiredActionsCount
                        <br><hr><b>In total</b> $numberOfLzTotal
                        <b><h3>Self-Hosted Agents Image:</h3></b>
                        <b>Agent pools using image</b> $numberOfAgentPools
                        <br><hr><b>Image users (projects)</b> $agentUsers
                        <b><h3>Platform Service Connections:</h3></b>
                        <b>Secrets</b> $numberOfSecrets
                        <br><hr><b>Secrets exp. in 60 days</b> $secretsExp60
                        <br><hr><b>Expired secrets</b> $expiredSecrets
                        <br><hr><b>Report creation time $("{0:dd.MM.yyyy HH:mm}" -f $dateAndTime) UTC</b> 
                    </td></tr>
                    <tr><td style="background-color: #eaeaea; line-height:15px">
                        <h5>This is an automatic notification sent by <a href="mailto:ccoe-platform@aldi-nord.de">Azure Platform Support Team</a><br>
                        <br>ALDI Nord $("{0:yyyy}" -f $dateAndTime)</h5>
                    </td></tr>
                </table>
            </center>
        </body>
"@

    return $body

}