<#
.SYNOPSIS
Creates 3 RBAC assignments
.DESCRIPTION
Creates 3 RBAC assignments with default roles: Reader, Contributor, Owner
.PARAMETER groupNameTemplate
Mandatory. Template that will be filled out to get group names
.PARAMETER groupIds
Mandatory. An array of group IDs to process role assignments.
.EXAMPLE
./tools/Scripts/Add-LZRoleAssignments.ps1 -groupNameTemplate "AZR.WW.MST.contoso.sub.DEV.{0}" -groupIds @("group1", "group2") -WhatIf:$true
#>
[CmdletBinding(SupportsShouldProcess)]
param(

    [Parameter(Mandatory = $true)]
    [hashtable] $groupIdsAll
)

foreach ($groupName in $groupIdsAll.Keys) {
    $groupId = $groupIdsAll[$groupName]

    if ($groupName -like "*reader*") {
        $roleName = "Reader"
    } elseif ($groupName -like "*owner*") {
        $roleName = "Owner"
    } else {
        $roleName = "Contributor"
    }

    # Check if role assignment already exists
    Write-Verbose  "Checking existing role assigments" -Verbose
    
    $assignment = Get-AzRoleAssignment -ObjectId $groupId | Where-Object { $_.RoleDefinitionName -eq $roleName }
    
    if ($assignment) {
        Write-Verbose "Role assignment already exists: '$roleName' for Group: $groupId" -Verbose
    } else {
        if ($PSCmdlet.ShouldProcess("Assigning '$roleName' role to Group: $groupId", "Invoke")) {
            Write-Verbose "Assigning '$roleName' role to Group: $groupId" -Verbose
            $assignment = New-AzRoleAssignment -ObjectId $groupId -RoleDefinitionName $roleName
        } else {
            Write-Verbose "Would assign '$roleName' role to Group: $groupId" -Verbose
        }
    }
    
    if ($assignment) {
        $assignment | Format-List
    }

}
