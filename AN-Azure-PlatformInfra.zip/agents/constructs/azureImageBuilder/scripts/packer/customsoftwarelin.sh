#!/bin/bash -e
################################################################################
##  File:  customsoftware.sh
##  Desc:  Installs custom software
################################################################################

source $HELPER_SCRIPTS/install.sh

# Install Terragrunt
echo 'Terragrunt installation'
json=$(curl -s "https://api.github.com/repos/gruntwork-io/terragrunt/releases/latest")
downloadUrl=$(echo $json | jq -r ".assets | .[] | select(.name==\"terragrunt_linux_amd64\").browser_download_url")
download_with_retries $downloadUrl "/tmp"
sudo mv /tmp/terragrunt_linux_amd64 /usr/local/bin/terragrunt
chmod +x /usr/local/bin/terragrunt

# Test installation
echo 'Test Terragrunt installation'
terragrunt --version